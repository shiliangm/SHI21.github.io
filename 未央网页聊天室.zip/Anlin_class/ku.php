<?php 
return array(
'server'=>'localhost',
'name'=>'3hk97jr29i222', 'pass'=>'passssss',
'b'=>'3hk97jr29i222'
);
?>