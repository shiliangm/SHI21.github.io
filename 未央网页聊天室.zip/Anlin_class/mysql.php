<?php


class mys{
private $db;
public $sqlname;

public function __construct(){
$sq=include('./Anlin_class/ku.php');
$this->sqlname=$sq['b'];
$db = mysqli_connect($sq['server'],$sq['name'], $sq['pass']) or die('<meta content="width=device-width,initial-scale=1.0,maximum-scale=1.0,user-scalable=no" id="viewport" name="viewport">	<meta charset="utf-8">'."数据库链接失败".mysqli_error());
mysqli_query($db,"set names utf8");
mysqli_set_charset($db,"utf8mb4");
@mysqli_select_db($db,$this->sqlname) or die('<meta content="width=device-width,initial-scale=1.0,maximum-scale=1.0,user-scalable=no" id="viewport" name="viewport">	<meta charset="utf-8">'."数据库表不存在");
$this->db=$db;
}

public function  __destruct(){mysqli_close($this->db);}



public function zeng($b,$v){
if(!$this->query("INSERT INTO $b VALUES(".$v.");")){return false;}else{return true;}

}

public function query($w){return mysqli_query($this->db,$w);}

public function fetch($sql){return @mysqli_fetch_array($sql);}

public function rowk($sqll){
$zxo=$this->query("SELECT count(*) as AllNum FROM $sqll");
$zv=mysqli_fetch_assoc($zxo);

return $zv['AllNum'];
}
public function row($sqll){

return @mysqli_num_rows($sqll);}

public function cha($b,$v){
return $this->fetch($this->query("SELECT*FROM $b where $v"));}

public function shan($b,$v){return $this->query("DELETE FROM $b where $v");}


public function gai($b,$v){return $this->query("UPDATE `$b` SET $v");}
public $zs='0';
public $ce='0';

public function chax($b,$sj,$sl){  
if(!$_GET['page']||$_GET['page']==''){$_GET['page']='0';}
$pag=$_GET['page']*$sl;

$zxo=$this->query("SELECT count(*) as AllNum FROM `$b` $sj");
$zv=mysqli_fetch_assoc($zxo);

$this->zs=$zv['AllNum'];

//$this->zs=$this->row($this->query("SELECT id FROM `$b` $sj"));

$this->ce=ceil($this->zs/$sl);
$my=$this->query("SELECT * FROM `$b` $sj limit $pag,$sl") or exit(mysqli_error());
while($i=$this->fetch($my)){
$ll[]=$i;
}
return $ll;
}





}
?>