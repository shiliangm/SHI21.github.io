<?php 
function bz($bz1,$bz2){return create_function($bz1,$bz2);}
function stylex($ss){
$ss=str_replace('color:','color!',$ss);

$ss=str_replace(':','',$ss);
$ss=str_replace('color!','color:',$ss);

return $ss;
}

function ua(){

if(preg_match('/(blackberry|configuration\/cldc|hp |hp-|htc |htc_|htc-|iemobile|kindle|midp|mmp|motorola|mobile|nokia|opera mini|opera |Googlebot-Mobile|YahooSeeker\/M1A1-R2D2|android|iphone|ipod|mobi|palm|palmos|pocket|portalmmm|ppc;|smartphone|sonyericsson|sqh|spv|symbian|treo|up.browser|up.link|vodafone|windows ce|xda |xda_)/i', $_SERVER['HTTP_USER_AGENT'])){return true;
}else{return false;}

}

function ubb($str){

$str=str_replace('[br]','<br>',$str);
$str=str_replace('[fontxc1]','<font class="xc1">',$str);
$str=str_replace('[/fontxc1]','</font>',$str);

$str=preg_replace_callback("/\[font=(.*?)\](.*?)\[\/font\]/is", bz( '$m', 'return "<font style=\"".stylex($m[1])."\">".$m[2]."</font>";' ), $str);

$st1[]="/\[url=(.+?)\](.+?)\[\/url\]/s";
$st1[]="/\[img=(.+?)\]\.\/imgcache\/(.+?)\[\/img\]/is";
$st1[]="/\[img\]\.\/bqimg\/(.+?)\[\/img\]/s";
$st1[]="/\[img\]\.\/imgcache\/(.+?)\[\/img\]/is";



$st2[]='<a href="\\1">\\2</a>';
$st2[]='<div class="listimg"><div class="loader loader-1"><div class="loader-inner"></div></div><img onload="imgkj();" class="tutu" src="./imgcache/\\2" alt="[图片]" style="height:\\1px;max-height:180px;visibility:hidden;" onclick="imu(this)"></div>';

$st2[]='<img alt="[表情]" src="./bqimg/\\1" style="max-width:100%;">';
$st2[]='<div class="listimg"><div class="loader loader-1"><div class="loader-inner"></div></div><img onload="imgkj();" class="tutu" src="./imgcache/\\1" alt="[图片]" style="max-height:180px;visibility:hidden;" onclick="imu(this)"></div>';


$st1[]="/\[size=(.+?)\](.*?)\[\/size\]/is";
$st2[]='<font style="font-weight:bold;font-size:\\1;">\\2</font>';

$str=preg_replace($st1,$st2,$str);



return $str;
}

function btubb($str)
{
$st1[]="/\[img\]([^\"].+?)\[\/img\]/s";
$st2[]='<img alt="[图标]" src="\\1" style="max-height:20px;">';


$str=preg_replace($st1,$st2,$str);
return $str;}


function htmlx($str)
{    
	$str = str_replace(">",    "&gt;",   $str);
	$str = str_replace("<",    "&lt;",   $str);
	$str = str_replace("\"",   "&quot;", $str);
$str = str_replace(" ",    "&nbsp;", $str);
$str = str_replace("\\",    "", $str);
	$str = str_replace("'",   "&prime;",$str);
 	$str = str_replace("\n",   "<br/>",$str);

	return $str;
}

?>