<?php 
include './config.php';
function bz($bz1,$bz2){return create_function($bz1,$bz2);}
$my=new mys;
$u=$my->cha("Anlin_user","name='".$_COOKIE['name']."' and pass='".$_COOKIE['pass']."'");

function nolog($s){
if($u['name']==''){return $s;}
}
function yeslog($s){
if($u['name']!=''){return $s;}
}

function wap($iinn){
if(preg_match('/(blackberry|configuration\/cldc|hp |hp-|htc |htc_|htc-|iemobile|kindle|midp|mmp|motorola|mobile|nokia|opera mini|opera |Googlebot-Mobile|YahooSeeker\/M1A1-R2D2|android|iphone|ipod|mobi|palm|palmos|pocket|portalmmm|ppc;|smartphone|sonyericsson|sqh|spv|symbian|treo|up.browser|up.link|vodafone|windows ce|xda |xda_)/i', $_SERVER['HTTP_USER_AGENT'])){return $iinn;
}

}

function pc($iinn){

if(preg_match('/(blackberry|configuration\/cldc|hp |hp-|htc |htc_|htc-|iemobile|kindle|midp|mmp|motorola|mobile|nokia|opera mini|opera |Googlebot-Mobile|YahooSeeker\/M1A1-R2D2|android|iphone|ipod|mobi|palm|palmos|pocket|portalmmm|ppc;|smartphone|sonyericsson|sqh|spv|symbian|treo|up.browser|up.link|vodafone|windows ce|xda |xda_)/i', $_SERVER['HTTP_USER_AGENT'])){}else{return $iinn;
}

}

function hurl($iinn){header("Location: ".$iinn);
exit;
}


function cha($b,$s='1',$sj,$htm){
global $my,$u,$a;
$kk='';
if($b=='Anlin_user'){
if($sj=='1'){
$sj="Anlin_user order by time desc"; //最新注册排序
}
if($sj=='2'){
$sj="Anlin_user order by time"; //最新早册排序
}
if($sj=='3'){
$sj="Anlin_user where y='1' order by time"; //超级管理员
}
if($sj=='4'){
$sj="Anlin_user where y='2' order by time"; //管理员
}
if($sj=='5'){
$sj="Anlin_user where y='3' order by time"; //普通用户
}
if($sj=='6'){
$sj="Anlin_user where y='4' order by time"; //被禁言用户
}
if($sj=='7'){
$sj="Anlin_user where y='0' order by time"; //被锁定用户
}
$que=$my->query("SELECT*FROM $sj LIMIT $s");
while($f=$my->fetch($que)){
$h=$htm;
$h=str_replace('{user}',$f['user'],$h);
$h=str_replace('{tx}',$f['tx'],$h);
$h=str_replace('{jb}',$f['jb'],$h);
$h=str_replace('{name}',$f['name'],$h);
$h=str_replace('{qx}',$f['qx'],$h);
$h=str_replace('{time}',date("Y-m-d H:i",$f['time']),$h);
if($a['wjt']=='0'){
$acc='?h=mess&wbb=anlin&sname='.$f['name'];
}else{$acc='mess-'.$f['name'].'.html';}
$h=str_replace('{url}',$acc,$h);
$kk.=$h;

}
}



if($b=='Anlin_chatlist'){
if($sj=='1'){
$sj="Anlin_chatlist order by time desc"; //最新活跃排序
}
if($sj=='2'){
$sj="Anlin_chatlist order by id desc"; //最新排序
}
if($sj=='3'){
$sj="Anlin_chatlist order by id"; //最旧排序
}
if(strstr($sj,'#')){
$sj=explode('#',$sj);
$sj="Anlin_chatlist where id='".$sj[1]."'"; //指定id排序
}
$que=$my->query("SELECT*FROM $sj LIMIT $s");
while($f=$my->fetch($que)){
$h=$htm;
$h=str_replace('{title}',$f['title'],$h);
$h=str_replace('{id}',$f['id'],$h);
$zx=substr_count($f['y'],'>');
$im=explode('|',$f['img']);
$h=str_replace('{zx}',$zx,$h);
$h=str_replace('{img}',$im[0],$h);
$h=str_replace('{qx}',$f['qx'],$h);
$h=str_replace('{time}',date("Y-m-d H:i",$f['time']),$h);
if($a['wjt']=='0'){
$acc='?h=chat&id='.$f['id'];
}else{$acc='chat-'.$f['id'].'.html';}
$h=str_replace('{url}',$acc,$h);
$kk.=$h;

}
}
//chat bbs ubbj
if($b=='Anlin_chatbbs'){
if($sj=='1'){
$sj="Anlin_chatbbs order by time desc"; //最新排序
}
if($sj=='2'){
$sj="Anlin_chatbbs order by h desc"; //最新排序
}
if($sj=='3'){
$sj="Anlin_chatbbs order by id"; //最旧排序
}
if(strstr($sj,'#')){
$sj=explode('#',$sj);
$sj="Anlin_chatbbs where chaid='".$sj[1]."'"; //指定id排序
}
$que=$my->query("SELECT*FROM $sj LIMIT $s");
while($f=$my->fetch($que)){
$h=$htm;
$h=str_replace('{title}',$f['title'],$h);
$h=str_replace('{id}',$f['id'],$h);


$h=str_replace('{time}',date("Y-m-d H:i",$f['time']),$h);
if($a['wjt']=='0'){
$acc='?h=bbs&wbb=anlin&id='.$f['id'];
}else{$acc='bbs-'.$f['id'].'.html';}
$h=str_replace('{url}',$acc,$h);
$kk.=$h;

}
}


return $kk;
}


function ubbj($str){
global $my,$u;
$str1[]="/\[cha=(.+?)\|(.+?)\|(.+?)\](.+?)\[\/cha\]/is";
$str2[]=bz( '$m', 'return cha($m[1],$m[2],$m[3],$m[4]);' );
$str1[]="/\[wap\](.+?)\[\/wap\]/is";
$str2[]=bz( '$m', 'return wap($m[1]);' );

$str1[]="/\[pc\](.+?)\[\/pc\]/is";
$str2[]=bz( '$m', 'return pc($m[1]);' );

$str1[]="/\[nolog\](.+?)\[\/nolog\]/is";
$str2[]=bz( '$m', 'return nolog($m[1]);' );

$str1[]="/\[yeslog\](.+?)\[\/yeslog\]/is";
$str2[]=bz( '$m', 'return yeslog($m[1]);' );

$str1[]="/\[hurl\](.+?)\[\/hurl\]/is";
$str2[]=bz( '$m', 'return hurl($m[1]);' );

$str=str_replace('{u_name}',$u['name'],$str);
$str=str_replace('{u_user}',$u['user'],$str);
$str=str_replace('{u_tx}',$u['tx'],$str);
$str=str_replace('{u_jb}',$u['jb'],$str);
$str=str_replace('{u_time}',date("Y-m-d H:i",$u['time']),$str);
$str=str_replace('{u_zs}',$my->row($my->query("SELECT id FROM Anlin_user")),$str);


for($fglo=0;$fglo<=count($str1)-1;$fglo++){
$str=preg_replace_callback($str1[$fglo], $str2[$fglo], $str);
}
return $str;
}





?>