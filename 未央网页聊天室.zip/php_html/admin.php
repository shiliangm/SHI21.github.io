<?php 

/**安林网络私聊列表20wl.cn 
mess.php?name=
**/
include './Anlin_class/define.php';
include './Anlin_class/ubb.php';
include './config.php';
include './if.php';
$time=time();
$mods=$_GET['mods'];
$ac=$_GET['ac'];
$my=new mys;
//当前用户信息开始
$name=htmlx($_COOKIE['name']);
if($name!=''){
$u=$my->cha("Anlin_user","name='".$name."' and pass='".htmlx($_COOKIE['pass'])."'");
}

function htmlz($str)
{    
	$str = str_replace(">",    "&gt;",   $str);
	$str = str_replace("<",    "&lt;",   $str);
	$str = str_replace("\"",   "&quot;", $str);
$str = str_replace(" ",    " ", $str);
	$str = str_replace("'",   "&prime;",$str);
	return $str;
}
function replac($v1,$v2,$v3){

$v3=str_replace($v2,$v1,$v3);
return $v3;
}
function html($str)
{    
	$str = replac(">",    "&gt;",   $str);
	$str = replac("<",    "&lt;",   $str);
	$str = replac("\"",   "&quot;", $str);
$str = replac(" ",    "&nbsp;", $str);
	$str = replac("\\'",   "&prime;",$str);
	$str = replac("\\'",   "′",$str);
		$str = replac(" ",   " ",$str);
	return $str;
}
if($mods=='login'){
$name=htmlx($_POST['name']);
$pass=md5($_POST['pass']);
$my->rowk("Anlin_user WHERE name='".$name."' and pass='$pass'")>0 or message('账号或密码有误');
setcookie("name",$name,$time+(86400*30));
setcookie("pass",$pass,$time+(86400*30));
message('登录成功','?h=admin');
}
if($name==''){exit(UTF8.'

<form action="?h=admin&mods=login" method="post">
账号<input type="text" name="name" ><br>

密码<input type="password" name="pass" ><br>

<input type="submit" value="登录后台">
</form>

');}

if($u['qx']!='1'){exit(UTF8."你没有权限-<a href='?h=zeng&mods=exit'>退出</a>");}
function qo($aa){
if($aa=='0'){$e='已被锁定';}
if($aa=='1'){$e='超级管理员';}
if($aa=='2'){$e='管理员';}
if($aa=='3'){$e='普通用户';}
if($aa=='4'){$e='已被禁言';}
if($aa=='5'){$e='马甲账户';}
return $e;
}
function fff($x,$x1,$x2){
global $a;
$fo=explode('|',$x2);
for($i=0;$i<=count($fo)-1;$i++){
$ko=explode('=',$fo[$i]);
$v.='<option value="'.$ko[0].'">'.$ko[0].'_'.$ko[1].'</option>';
}
return '<form action="?h=admin&mods=shezhi&bt='.$x1.'" method="post">'.$x.':
<select name="nr">
<option value="'.$a[$x1].'">'.$a[$x1].'_</option>
'.$v.'
</select>
<input type="submit" value="修改">
</form><hr>';
}


if($mods=='userpo'){
login();
if($u['qx']!='1'){message('没有权限');}
$usid=htmlx($_GET['id']);
$qxid=htmlx($_POST['qx']);
$jb=htmlx($_POST['jb']);
$user=htmlx($_POST['user']);
if($user==''){message('不能为空');}
if($qxid==''){message('error');}
$k=$my->rowk("Anlin_user WHERE id='".$usid."'");
if($k<1){exit('用户不存在');}
if($my->gai("Anlin_user","user='$user',qx='$qxid',jb='$jb',t='".$_POST['t']."' WHERE id='$usid'")){message('修改成功');}
}//qx: 1,2管理员 3普通用户 4被禁言用户 0锁定用户 


if($mods=='scuserchats'){$name=$_GET['name'];
$my->shan("Anlin_chat","kname='$name'");
message('删除成功');
}
if($mods=='scuser'){
$name=$_GET['name'];
if($name==''){message('已删除');}
if($my->rowk("Anlin_user where id='1' and name='$name'")>0){message('删除失败,您不能删除网站创始人');}
$my->shan("Anlin_user","name='$name'");
$my->shan("Anlin_chat","kname='$name'");
$my->shan("Anlin_chatmess","kname='$name'");
$my->shan("Anlin_userset","kname='$name'");
@unlink('./tx/'.urlencode($name).'.png');
message("删除成功");
}
if($mods=='messxx'){
login();
$id=htmlx($_GET[id]);
if($u['qx']!='1'){exit('没有权限');}

$my->shan('Anlin_chatmess',"id='$id'");
exit('删除成功');
}


if($mods=='filecc'){
$dir='./imgcache';
$dh=opendir($dir); 
$cc=$_GET['cc'];
while ($file=readdir($dh)) { 
if($file!="." && $file!="..") { 
$fullpath=$dir."/".$file;

$size = filesize($fullpath);
$size =($size/1024) ;
$ft=filectime($fullpath);
if($cc=='2'){
if($ft+(86400*2)<$time){unlink($fullpath);}
}
if($cc=='3'){
if($ft+(86400*3)<$time){unlink($fullpath);}
}
if($cc=='5'){
if($ft+(86400*5)<$time){unlink($fullpath);}
}
if($cc=='10'){
if($ft+(86400*10)<$time){unlink($fullpath);}
}
if($cc=='30'){
if($ft+(86400*30)<$time){unlink($fullpath);}
}

if($cc=='180'){
if($ft+(86400*180)<$time){unlink($fullpath);}
}
if($cc=='360'){
if($ft+(86400*360)<$time){unlink($fullpath);}
}
if($cc=='0'){
unlink($fullpath);
}

if($cc=='1'){
if($size>1000){unlink($fullpath);}
}


}
}

message('删除成功');
}

if($mods=='chatpo'){
$id=$_GET['id'];
$qx=htmlx($_POST['qx']);
$title=htmlx($_POST['title']);
if($title==''){message('Error');}
if($my->gai("Anlin_chatlist","qx='$qx',title='$title' WHERE id='$id'")){message('修改成功');}
}

if($mods=='scchats'){

$id=$_GET['id'];
$ts=$_GET['ts'];
if($id!=''){
$str=$my->fetch($my->query("SELECT id,content FROM Anlin_chat where id='$id'"));
$str=$str['content'];
$str=preg_replace_callback("/\[img=(.*?)\]\.\/imgcache\/(.*?)\[\/img\]/is", bz( '$m', 'unlink("./imgcache/".$m[2]);' ), $str);
$my->shan("Anlin_chat","id='$id'");
}
if($ts!=''){
if(!ifs($ts,'zdy','0-9')){message('只能输入数字');}
$xt=time()-(86400*$ts);
$my->shan("Anlin_chat","time<'$xt'");
}
message("删除成功");

}

if($mods=='scchat'){
$id=$_GET['id'];
$my->shan("Anlin_chatlist","id='$id'");
$my->shan("Anlin_chat","chaid='$id'");

message("删除成功");

}
if($mods=='scchatm'){
$id=$_GET['id'];
$my->shan("Anlin_chat","chaid='$id'");
message("删除成功");

}

if($mods=='shezhi'){
$bt=$_GET['bt'];
$nr=htmlx($_POST['nr']);
if($nr==''){message('提交为空');}
$du=file_get_contents('./config.php');
$du=preg_replace("/\'".$bt."\'\=\>\'(.*?)\',/s","'".$bt."'=>'".$nr."',",$du);
file_put_contents('./config.php',$du);
message('修改成功');
}
if($mods=='smtp'){

if($_POST['smtptip']==''){message('提交为空');}
$du=file_get_contents('./config.php');
$du=preg_replace("/\'smtpserver\'\=\>\'(.*?)\',/s","'smtpserver'=>'".$_POST['smtpserver']."',",$du);
$du=preg_replace("/\'smtpdk\'\=\>\'(.*?)\',/s","'smtpdk'=>'".$_POST['smtpdk']."',",$du);
$du=preg_replace("/\'smtpmail\'\=\>\'(.*?)\',/s","'smtpmail'=>'".$_POST['smtpmail']."',",$du);
$du=preg_replace("/\'smtpuser\'\=\>\'(.*?)\',/s","'smtpuser'=>'".$_POST['smtpuser']."',",$du);
$du=preg_replace("/\'smtppass\'\=\>\'(.*?)\',/s","'smtppass'=>'".$_POST['smtppass']."',",$du);
$du=preg_replace("/\'smtptip\'\=\>\'(.*?)\',/s","'smtptip'=>'".$_POST['smtptip']."',",$du);
file_put_contents('./config.php',$du);
message('修改成功');
}

//文件上传
if($mods=='filepo'){
if(!is_dir('./bbsimg')){mkdir('./bbsimg');}
$file=$_FILES[file];
if($file["name"]!=""){
$filebk=mb_substr($file["name"],mb_strlen($file["name"],'utf8')-3,mb_strlen($file["name"],'utf8'),'utf-8');
$filebk=strtolower($filebk);
if(in_array($filebk,array('png','gif','jpg','peg'))){}else{exit('文件格式错误');}
$os[filesize]='5000';
if(($file["size"]/1024)>$os[filesize]){
if($os[filesize]>1024){
$fsi=ceil($os[filesize]/1024)."MB";
}else{$fsi=ceil($os[filesize]).'KB';}
exit('图片不能大于5MB');
}

$filename=$time.str_replace("%",'_',urlencode($file["name"]));

if(move_uploaded_file($file["tmp_name"],'./bbsimg/'.$filename)){
exit('<img src="./bbsimg/'.$filename.'">');
}
}
//file 
exit('图片上传失败');

}

//聊天室图片
if($mods=='chatimg'){
if(!is_dir('./chatimg')){mkdir('./chatimg');}
$file=$_FILES[file];
if($file["name"]!=""){
$filebk=mb_substr($file["name"],mb_strlen($file["name"],'utf8')-3,mb_strlen($file["name"],'utf8'),'utf-8');
$filebk=strtolower($filebk);
if(in_array($filebk,array('png','gif','jpg','peg'))){}else{exit('文件格式错误');}
$os[filesize]='5000';
if(($file["size"]/1024)>$os[filesize]){
if($os[filesize]>1024){
$fsi=ceil($os[filesize]/1024)."MB";
}else{$fsi=ceil($os[filesize]).'KB';}
message('图片不能大于5MB');
}

if(substr($file['name'],-3)=='gif'){$wei='gif';}else{$wei='png';}
$lx=$_GET['lx'];
$filename=str_replace("%",'_',urlencode($_GET['chaid'].'.'.$wei));
if($lx=='x'){$filename='x_'.$filename;}
if(move_uploaded_file($file["tmp_name"],'./chatimg/'.$filename)){
$or=$my->fetch($my->query("SELECT*FROM Anlin_chatlist where id='".$_GET['chaid']."'"));
$x=explode('|',$or['img']);
if($lx=='x'){$mg='./chatimg/'.$filename.'|'.$x[1];}else{$mg=$x[0].'|./chatimg/'.$filename;}
$my->gai("Anlin_chatlist","img='$mg' where id='".$_GET['chaid']."'");
message('修改成功');
}
}
//file 
message('请选择图片');

}
//聊天室图片


if($mods=='xgtx'){
//file 
login();
$file=$_FILES[file];
if($file["name"]!=""){
$filebk=mb_substr($file["name"],mb_strlen($file["name"],'utf8')-3,mb_strlen($file["name"],'utf8'),'utf-8');
$filebk=strtolower($filebk);
if(in_array($filebk,array('png','gif','jpg','peg'))){}else{message('文件格式错误');}
$os[filesize]='500';
if(($file["size"]/1024)>$os[filesize]){
if($os[filesize]>1024){
$fsi=ceil($os[filesize]/1024)."MB";
}else{$fsi=ceil($os[filesize]).'KB';}
message('图片不能大于500KB');
}
include './imgs.php';
$filename=str_replace("%",'_',urlencode($u['name'].'.png'));
$tlu="./tx/null.png";
@unlink($tlu);
if(move_uploaded_file($file["tmp_name"],$tlu)){
imgc($tlu,200,200,$tlu);

message('修改成功');
}
}
//file 
message('请选择图片');

}



$url=LL.'?'.$_SERVER['QUERY_STRING'];
echo'<html><head><meta http-equiv="Expires" content="0">
<meta http-equiv="Pragma" content="no-cache">
<meta http-equiv="Cache-control" content="no-cache,must-revalidate">
<meta http-equiv="Cache" content="no-cache">';
echo UTF8;
include './php_html/global/head.php';
?>
</script>
</head><body>
<?php include './php_html/global/load.html';

?>
<div style="height:30px;"></div>
<div class="header"><div class="left"><a id="nologin" onclick="window.history.go(-1);">⬅︎</a>
</div>
<div class="center">超级管理后台<div style="font-size:65%;">请至插件安装页面查看后台更新</div></div>
<div id="mstsxxx" class="right" onclick="window.location.href='?h=zeng&mods=exit';">退出</div>
<div id="both" style="margin-bottom:4px;"></div>
<div id="both"></div>
</div><style>
.tip{line-height:33px;vertical-align:middle;margin-bottom:5px;border:5px #46338b solid;}.t a{color:#fff;}
.tip .t{background:#46338b;line-height:35px;padding:0 10px 0px 10px;color:#fff;}
.tip .c{padding:10px 10px 10px 10px;line-height:33px;color:#000;}
</style>

<div id="list" class="" style="display:block;line-height:30px;">
<?if($ac=='qj'){
echo'
<div class="tip">
<div class="t">全局设置</div>
<div class="c">
聊天图片清理(定期清理以节省磁盘空间):<button type="button" onclick="que(\'?h=admin&mods=filecc&cc=360\')">删除1年前所有图片</button><button type="button" onclick="que(\'?h=admin&mods=filecc&cc=180\')">删除半年前所有图片</button><button type="button" onclick="que(\'?h=admin&mods=filecc&cc=30\')">仅保留近30天图片</button><button type="button" onclick="que(\'?h=admin&mods=filecc&cc=10\')">仅保留近10天图片</button><button type="button" onclick="que(\'?h=admin&mods=filecc&cc=5\')">仅保留近5天图片</button><button type="button" onclick="que(\'?h=admin&mods=filecc&cc=3\')">仅保留近3天图片</button><button type="button" onclick="que(\'?h=admin&mods=filecc&cc=2\')">仅保留近2天图片</button><button type="button" onclick="que(\'?h=admin&mods=filecc&cc=1\')">仅删除大于1M的图片</button><button type="button" onclick="que(\'?h=admin&mods=filecc&cc=0\')">删除全部图片</button>
<hr>
<form action="?h=admin&mods=shezhi&bt=title" method="post">网站标题:
<input type="text" name="nr" value="'.$a['title'].'">
<input type="submit" value="修改">
</form><hr>

<form action="?h=admin&mods=shezhi&bt=zc" method="post">注册方式:
<select name="nr">
<option value="'.$a['zc'].'">'.$a['zc'].'_</option>
<option value="0">0_注册后需要审核(锁定用户)</option>
<option value="1">1_邀请码注册(需要填写指定邀请码)</option>
<option value="2">2_关闭注册(无法注册账号)</option>
<option value="3">3_正常注册(没有限制)</option>
<option value="4">4_邮件注册(需要验证)</option>
</select>
<input type="submit" value="修改"> 
<br><a href="?h=admin&ac=yqm">邀请码设置</a> | <a href="Javascript:void(0)" onclick="$(\'#smtp\').toggle();">SMTP设置</a> | 邮件注册请务必设置smtp服务器确保信息正确(自己在前台注册小号尝试)
</form>
<style>#smtp input{width:100%;}</style>
<div id="smtp" style="display:none;">
<form action="?h=admin&mods=smtp" method="post">SMTP服务器地址:
<input type="text" name="smtpserver" value="'.$a['smtpserver'].'"><br>
SMTP端口:<br><input type="text" name="smtpdk" value="'.$a['smtpdk'].'"><br>
SMTP邮箱:<br><input type="text" name="smtpmail" value="'.$a['smtpmail'].'"><br>
SMTP发件人(与邮箱一致):<br><input type="text" name="smtpuser" value="'.$a['smtpuser'].'"><br>
SMTP邮箱密码:<input type="text" name="smtppass" value="'.$a['smtppass'].'"><br>
邮件内容(代码: [title]网站标题,[url]激活链接,[user]注册者用户名,[name]注册者账号):<br>
<textarea name="smtptip" style="width:100%;height:100px;">'.$a['smtptip'].'</textarea><br>
<input type="submit" value="修改">
</form>

</div>

<hr>

'.fff('聊天室消息刷新频率(如网站有cc防火墙请勿低于3s)','get','1=1s|2=2s|3=3s|4=4s|5=5s|6=6s|7=7s').fff('会员在线更新时间(单位: 秒)','zx','1800=30分钟|180=3分钟|600=10分钟|3600=1小时|7200=2小时|86400=1天|43200=12小时').fff('消息每页显示数量(包含论坛)','sl','10=10条|15=15条|20=20条|25=25条|30=30条|35=35条|40=40条|50=50条|100=100条').fff('是否开启图片发送','file','1=开启|0=关闭').fff('是否允许修改头像','tx','1=允许|0=关闭').fff('发送消息最大字数','z','200=200字|100=100字|300=300字|400=400字|500=500字|600=600字').fff('是否允许普通会员之间私聊(管理员无限制)','mess','1=允许|0=不允许').fff('所有聊天室发言开关(管理员无限制)','go','1=正常发言|0=关闭发言').fff('聊天室图片文件大小限制(单位K)','fibk','1000=1M|500=500K|1500=1500K|2000=2000K|3000=3000K|4000=4000K|5000=5000K').fff('伪静态开关','wjt','0=关闭|0=关闭').'
<form method="post" action="?h=admin&mods=xgtx" enctype="multipart/form-data" id="J-add-form">
当前默认头像:<img src="./tx/null.png" style="width:33px;"><br>
选择图片:
<input type="file" name="file" id="cfile" onchange="show(this)" style="display:n;">
<input type="submit"value="修改">
</form><hr>



</div>
</div>
';
}
?>
<?
if($ac=='yqm'){
$du=file_get_contents('./txts/#zc.txt');
if($mods=='scyqm'){
$du=preg_replace("/\{".$_GET['r']."\|(.*?)\}/is",'',$du);
file_put_contents('./txts/#zc.txt',$du);
message('删除成功,请刷新页面');
}
if($mods=='tjyqm'){
if(strstr($du,'{'.$_POST['r'].'|')){message('已存在相同邀请码');}
if($_POST['r']==''){message('邀请码不能为空');}
if($_POST['c']==''){message('次数不能为空');}
if(!is_numeric($_POST['c'])){message('次数必须为数字');}


file_put_contents('./txts/#zc.txt',$du.'{'.$_POST['r'].'|'.$_POST['c'].'}');
message('添加成功,请刷新页面');
}


$lu=preg_replace("/\{(.*?)\|(.*?)\}/is",'邀请码:<b>\\1</b> | 剩余次数:<b>\\2</b> | <a href="?h=admin&ac=yqm&mods=scyqm&r=\\1">删除</a><hr>',$du);
echo'<div class="tip">
<div class="t">邀请码设置</div>
<div class="c">
<form action="?h=admin&ac=yqm&mods=tjyqm" method="post">邀请码必须将网站设置成邀请码注册才能使用<br>
输入自定义邀请码(支持文字 英文和数字)<input name="r" value="">
<br>邀请码次数:(规定该邀请码可以注册几次)<input name="c" value="1">
<input type="submit" value="添加邀请码">
</form><hr>


'.$lu.'

</div></div>
';
}


if($mods=='tjhy'){
$name=htmlx($_POST['name']);
$user=htmlx($_POST['user']);
$pass=md5($_POST['pass']);
$qx=$_POST['qx'];
if($name==''||$user==''){message('账号或昵称最低1个字符');}
!$my->rowk("Anlin_user WHERE name='$name'") or message('账号已存在');
!$my->rowk("Anlin_user WHERE user='$user'") or message('昵称已存在');
if($my->zeng('Anlin_user',"NULL,'$name','$pass','$user','$qx','0','./tx/null.png','$time','".$_POST['t']."'")){

message('添加成功,请刷新页面');
}
}

if($ac=='xuni'){
if($mods=='xuni'){
$zp=$_POST['zp'];
if($zp==''){message('不能为空');}
$zp=str_replace('\\',"",$zp);
file_put_contents('./txts/#zaix.txt',$zp);
message('修改成功,请刷新页面');
}

$du=file_get_contents('./txts/#zaix.txt');
$du=str_replace('><',">\n<",$du);
echo'
<div class="tip">
<div class="t">虚拟在线会员设置</div>
<div class="c">
'.fff('设置在线会员的显示方式','zxlist','1=横向排序|2=纵向排序').'
本页面设置虚拟在线会员充当在线人数(只有管理员能点击查看列表会员资料,点击虚拟在线会员则显示自己的资料),格式如下:<br>
<b style="color:#ff0000">&lt;"昵称"头像链接"&gt;</b>
<br>头像链接可以使用任意<a href="http://sm.ms">第三方链接</a>,使用默认头像输入字母 tx  例如: <b style="color:#ff0000">&lt;"昵称"tx"&gt;</b><br>真实会员靠前,虚拟会员靠后,你也可以设置真实会员 格式为:<b style="color:#ff0000">&lt;会员账号"昵称"头像链接"&gt;</b> (会员账号为必须 昵称和头像可自定义,真实会员账号前面不要加"号 这是标准格式,因为虚拟会员是无账号的可以省略不填)
<form action="?h=admin&ac=xuni&mods=xuni" method="post">
<textarea name="zp" style="width:99%;height:500px;">
'.$du.'
</textarea>
<input type="submit" value="提交修改">
</form>
</div>
</div>
';

}

if($ac=='gofile'){
$mu=$_GET['mu'];
$gw=$_GET['gw'];
$mu='./anlin/'.$mu.'.php';
//if(!file_exists($mu)){
$se=file_get_contents('http://ssr.20wl.cn/'.$gw);
if($se==''){message('远程插件服务器连接失败,请稍后再试');}
file_put_contents($mu,$se);
if(!file_exists($mu)){message('插件获取失败,请联系软件开发商');}
//}
echo'
<div class="tip">
<div class="t">'.$_GET['name'].'</div>
<div class="c">
';

include($mu);

echo'</div></div>';
}

if($ac=='po20wl'){
$se=file_get_contents('http://ssr.20wl.cn/chat/chaj/');

if($se==''){$se='远程插件服务器连接失败,请稍后再试';}
echo'
<div class="tip">
<div class="t">插件扩展</div>
<div class="c">

'.$se.'

</div>
</div>
';
}
$dir='./php_html/Moban';



if($ac=='ubbj'){
if($mods=='scubbj'){
if($_GET['x']=='index.anlin'){message('网站默认首页无法删除');}

unlink($dir.'/'.$_GET['x']);
message('删除成功');
}

echo'<div class="tip">
<div class="t">ubbj自定义页面模板</div>
<div class="c">
什么是UBBJ?<br>
<a style="color:#ff0000">UBBJ是一个将网站复杂的数据简化成一个易懂的代码,用户可以通过这些代码来自由的排版网站,你可以在这里创建自定义页面它们都将支持ubbj,我们将尽快更新更多的ubbj代码 请关注插件列表</a><br>
';


if($mods=='xgubbj'){
$xd=file_get_contents($dir.'/'.$_GET['x']);
if($_GET['w']=='go'){
if($_POST['zp']==''||$_POST['x']==''){message('不能为空');}
if(!ifs($_POST['x'],'zdy','a-zA-Z0-9\-\._')){message('模板名只能使用英文和数字,符号可用 ._-');}
file_put_contents($dir.'/'.$_POST['x'],str_replace('	',' ',html($_POST['zp'])));
message('OK');
}

echo'
<form action="?h=admin&ac=ubbj&mods=xgubbj&w=go" method="post">
模板名:<input type="text" name="x" value="'.$_GET['x'].'"><br>内容(Html/js/css/ubbj)<button type="button" onclick="$(\'#ub\').show();">UBBJ代码</button><br>
<textarea name="zp" style="width:99%;height:400px;">
'.htmlz($xd).'
</textarea>
<input type="submit" value="提交修改">
</form>

';




}

if($mods==''){
$dh=opendir($dir); 
echo'<div class="t">模板列表</div>';
while ($file=readdir($dh)) { 
if($file!="." && $file!="..") { 
$fullpath=$dir."/".$file;
$size = filesize($fullpath);
$size =($size/1024) ;
if($file=='index.anlin'){$fn='(index.anlin默认首页,无法删除)';}else{$fn='自定义页面(<b style="color:#ff4500">'.$file.'/'.ceil($size).'K</b>)';}
echo '模板名:'.$fn.' | <a href="?x='.$file.'">访问页面</a> | <a href="?h=admin&ac=ubbj&mods=xgubbj&x='.$file.'">修改</a> | <a onclick="que(\'?h=admin&ac=ubbj&mods=scubbj&x='.$file.'\')">删除</a> <hr>';
}
}
}//mods
$mor=htmlx(file_get_contents('./php_html/ubbj.txt'));

echo'
<div id="ub" style="display:none;">
<div style="max-width:650px;position:fixed;top:0;left:0;right:0;margin:0 auto;line-height:35px;text-align:center;background:#ff0000;color:#fff;z-index:1000;" onclick="$(\'#ub\').hide();">关闭</div>
<div style="max-width:650px;position:fixed;top:35px;left:0;right:0;margin:0 auto;height:500px;overflow-y:scroll;line-height:35px;text-align:left;background:#000;color:#fff;z-index:1000;"><div style="padding:0px 20px 0px 20px;">
'.str_replace("\n",'<br>',$mor).'


</div>
</div>
</div>
<div class="t">新建页面</div>
<form action="?h=admin&ac=ubbj&mods=xgubbj&w=go" method="post">
模板名:<input type="text" name="x" value=""><br>内容(Html/js/css/ubbj):<button type="button" onclick="$(\'#ub\').show();">UBBJ代码</button><br>
<textarea name="zp" style="width:99%;height:300px;">
'.htmlz($xd).'
</textarea>
<input type="submit" value="新建页面">
</form>

</div></div>';

}


if($ac=='bbsfb'){
if($mods=='scbbs'){
$id=$_GET['id'];
$my->shan("Anlin_chatbbs","id='$id'");
$my->shan("Anlin_chatbbshui","bbsid='$id'");

message('删除成功');
}
if($mods=='xgbbs'){
$id=$_GET['id'];
$title=html($_POST['title']);
$content=html($_POST['content']);

$chaid=$_POST['chaid'];
$qx=$_POST['qx'];
$d=$_POST['d'];
if($content==''||$title==''){message('标题或内容不能为空');}
$my->gai("Anlin_chatbbs","title='$title',content='".$content."',chaid='$chaid',qx='$qx',d='$d' where id='$id'");
message('修改成功');
}
if($mods=="bbsgo"){
$title=html($_POST['title']);
$content=html($_POST['content']);
$chaid=$_POST['chaid'];
$qx=$_POST['qx'];
$d=$_POST['d'];
if($title==''){message('标题不能为空');}
//if($my->row($my->query("SELECT id FROM Anlin_chatlist WHERE id='$chaid'"))<1){message('');}
if($my->zeng("Anlin_chatbbs","NULL,'$chaid','$title','$qx','$content','$d','0','$time'")){message("发布成功");}
message('发布失败');
}

$larr=$my->query("SELECT id,title FROM Anlin_chatlist order by time desc");
while($f=$my->fetch($larr)){
$lb.='<option value="'.$f['id'].'">'.$f['title'].'</option>';
}
?>
<div class="tip">
<div class="t">帖子发布</div>
<div class="c">
<form method="post" action="" enctype="multipart/form-data" id="J-add-form" style="display:none;">
 <input type="file" name="file" id="cfile" accept="image/*" onchange="chatbbs();" style="display:none;">
</form>
<form id="fa" action="<?=$url?>&mods=bbsgo" method="post">
发布到:<select name="chaid"><option value='0'>所有聊天室</option><?=$lb?></select><br>
帖子标题:<br><input type="text" name="title" value=""><br><b style="color:#ff0000">标题可通过html插入图片<br>
私信链接为: ?h=mess&wbb=1&sname=被私信者账号 (注意:会员账号不是昵称)</b><br>
帖子内容(可使用html):<button type="button" onclick="document.getElementById('cfile').click();">插入图片</button><br>
<div id="textcon2" style="overflow-y:auto;-webkit-user-modify: read-write-plaintext-only;background-color:rgba(255,255,255,.8);border:1px #e0e0e0 solid;width:99%;height:230px;line-height:20px;"></div>
<b style="color:#ff0000">电脑可直接右键粘贴插入图片,支持QQ(需放大复制)/微信/浏览器网页复制的图片</b>
<textarea style="display:none;" id="content" name="content"></textarea><br>
是否允许回复:<select name="qx"><option value="1">允许</option><option value="0">不允许</option></select><br>
初始热度(必须为数字):<input type="text" name="d" value="<?=rand(100,999)?>"><br>
<input type="button" value="发布" onclick="subpo();">
</form>
</div></div>
<div id="ts" class="ts" style=""></div>
<style>#textcon2 img{max-width:100px;}</style>
<script>
function subpo(){
var zcon=$("#textcon2").html();
$("#content").val(zcon);
document.getElementById('fa').submit();
}
var xji='';
function chatbbs(){

ts('正在上传中...');


    var formData = new FormData(document.getElementById("J-add-form"));
if(xji!=''){
formData.append("file",xji);
}
    $.ajax({
          url:'?h=admin&mods=filepo',
          type:'post',
          dataType:'text', 
          data:formData,
          cache: false,            
          processData: false,      
          contentType: false,      
          success:function(data){
          ts(data);

if(data.indexOf("<img")!=-1){
ts('添加成功');
$("#textcon2").append(data);
xji='';

}else{ts(data);}


          },
          error:function(e){
              ts('服务器繁忙,请重试！');xji='';

           }
    });
}

			document.addEventListener("paste", function (e) {

    let items = event.clipboardData && event.clipboardData.items;
    let file = null;
    if (items && items.length) {
        // 检索剪切板items中类型带有image的
        for (var i = 0; i < items.length; i++) {
            if (items[i].kind === 'file') { // 或者 items[i].type.indexOf('image') !== -1
                file = items[i].getAsFile(); // 此时file就是剪切板中的图片文件
xji=file;
				
chatbbs();
                break;
            }
        }
    }
}, false);
function xinn(xx){

var reader = new FileReader();

reader.readAsDataURL(xx);

reader.onload = function (e) {
 
   $("#img").attr('src',e.target.result);
}
}
</script>
<?}

if($ac=='xgtz'){
$larr=$my->query("SELECT id,title FROM Anlin_chatlist order by time desc");
while($f=$my->fetch($larr)){
$lb.='<option value="'.$f['id'].'">'.$f['id'].'_'.$f['title'].'</option>';
}
$sh=$my->cha("Anlin_chatbbs","id='".$_GET['id']."'")
?>
<div class="tip">
<div class="t">帖子修改</div>
<div class="c">
<form action="?h=admin&ac=bbsfb&mods=xgbbs&id=<?=$_GET['id']?>" method="post">
板块:<select name="chaid">
<option value="<?=$sh['chaid']?>"><?=$sh['chaid']?>_</option>
<option value='0'>0_所有聊天室</option><?=$lb?></select><br>
帖子标题:<br><input type="text" name="title" value="<?=htmlz($sh['title'])?>"><br>
帖子内容(可使用html):<br>
<textarea name="content" style="width:99%;height:200px;"><?=htmlz($sh['content'])?></textarea><br>
是否允许回复:<select name="qx"><option value="<?=$sh['qx']?>"><?=$sh['qx']?></option><option value="1">1_允许</option><option value="0">0_不允许</option></select><br>
热度(必须为数字):<input type="text" name="d" value="<?=$sh['d']?>"><br>
<input type="submit" value="修改">
</form>
</div></div>
<?
}

//会员之间的对话
if($ac=='userdh'){
if($mods=='scdh'){
$id=$_GET['id'];

$my->shan("Anlin_chatmess","chaid='$id'");
$my->shan("Anlin_chatmesslist","id='$id'");
message('删除成功');
}


echo'<div class="tip">
<div class="t">会员对话删除(括号中是会员账号)</div>
<div class="c">';
$o=$my->chax("Anlin_chatmesslist","$t order by time desc",20);
//sql_ajax全能翻页开始
if(!$_GET['page']||$_GET['page']==''){$_GET['page']='0';}
if($_GET['page']>$my->ce-1){
message('没有内容了','');
}
if($_GET['page']<0){
message('没有内容了');
}
//for输出聊天数组
$co=count($o)-1;
for($i=0;$i<=$co;$i++){
$d1=$my->fetch($my->query("SELECT user FROM Anlin_user where name='".$o[$i]['kname']."'"));
$d2=$my->fetch($my->query("SELECT user FROM Anlin_user where name='".$o[$i]['sname']."'"));
echo $d1['user'].'<font style="font-size:12px;">('.$o[$i]['kname'].')</font> 与 '.$d2['user'].'<font style="font-size:12px;">('.$o[$i]['sname'].')</font> | <button onclick="que(\'?h=admin&ac=userdh&mods=scdh&id='.$o[$i]['id'].'\')">删除它们全部对话</button>
<hr>
';
}
echo'<a href="?h=admin&ac='.$_GET['ac'].'&mods='.$mods.'&ear='.$_GET['ear'].'&page='.($_GET['page']-1).'">上一页</a>'.($_GET['page']+1).'/'.$my->ce.'<a href="?h=admin&ac='.$_GET['ac'].'&mods='.$mods.'&ear='.$_GET['ear'].'&page='.($_GET['page']+1).'">下一页</a> 总数: '.$my->zs.'</div></div>';



}

if($ac=='bbslb'){
?>
<div class="tip">
<div class="t">帖子列表</div>
<div class="c">

<?
echo fff('聊天室帖子刷新频率','bbspl','5=5秒|10=10秒|50=50秒|600=600秒|9999999999=关闭帖子显示').fff('聊天室帖子排序方式','bbspx','1=最新发布|2=按热度|3=最早发布|4=按回复').fff('聊天室帖子显示条数','bbsts','5=5条|10=10条|15=15条|20=20条');

$o=$my->chax("Anlin_chatbbs","$t order by time desc",20);
//sql_ajax全能翻页开始
if(!$_GET['page']||$_GET['page']==''){$_GET['page']='0';}
if($_GET['page']>$my->ce-1){
message('没有内容了','');
}
if($_GET['page']<0){
message('没有内容了');
}
//for输出聊天数组
$co=count($o)-1;
for($i=0;$i<=$co;$i++){
if($o[$i]['chaid']=='0'){$xx='全部聊天室';}else{
$gou=$my->fetch($my->query("SELECT title FROM Anlin_chatlist where id='".$o[$i]['chaid']."'"));
$xx='<a href="?h=chat&id='.$o[$i]['chaid'].'">'.$gou['title'].'</a>';}
echo '
标题:<a href="?h=bbs&id='.$o[$i]['id'].'">'.$o[$i]['title'].'</a> | 所属聊天室: '.$xx.' | <a href="?h=admin&ac=xgtz&id='.$o[$i]['id'].'">修改</a> | <a onclick="que(\'?h=admin&ac=bbsfb&mods=scbbs&id='.$o[$i]['id'].'\')">删除</a>
<hr>
';
}
echo'<a href="?h=admin&ac='.$_GET['ac'].'&mods='.$mods.'&ear='.$_GET['ear'].'&page='.($_GET['page']-1).'">上一页</a>'.($_GET['page']+1).'/'.$my->ce.'<a href="?h=admin&ac='.$_GET['ac'].'&mods='.$mods.'&ear='.$_GET['ear'].'&page='.($_GET['page']+1).'">下一页</a> 总数: '.$my->zs.'</div></div>';


}

if($ac==''){?>
<div class="tip">
<div class="t">网站设置</div>
<div class="c">
<a href="?h=admin&ac=ubbj">UBBJ模板</a> | <a href="?h=admin&ac=qj">全局设置</a> | <a href="?h=admin&ac=yqm">注册邀请码设置</a> | <a href="?h=admin&ac=xuni">设置虚拟在线会员和显示设置</a>  | <a href="?h=admin&ac=po20wl">插件在线安装</a>
</div>
</div>
<div class="tip">
<div class="t">聊天室管理</div>
<div class="c">
<a href="?h=admin&ac=chat&mods=">聊天室列表管理/消息清空</a> | <a href="?h=admin&ac=chats&mods=">聊天室全部消息管理</a> | <a href="?h=admin&ac=bbslb">聊天室帖子管理</a> | <a href="?h=admin&ac=bbsfb">帖子发布</a>
<form action="?h=zeng&mods=chatlist" method="post">
输入名称:<input type="text" name="title" >
<input type="submit" value="创建聊天室">
</form>
<form action="?" method="get">
<input type="hidden" name="h" value="admin"><input type="hidden" name="ac" value="chats">
输入会员账号或昵称:<input type="text" name="ear" >
<input type="submit" value="查找聊天记录">
</form>
</div>
</div>


<div class="tip">
<div class="t">会员管理</div>
<div class="c">
<a href="?h=admin&ac=usergl">全部会员管理</a> |  <a href="?h=admin&ac=usergl&mods=sh">被锁用户管理</a> | <a href="?h=admin&ac=usergl&mods=mj">马甲账号管理</a> | <a href="?h=admin&ac=usergl&mods=g">管理员账号管理</a> | <a href="?h=admin&ac=admingl" style="color:#ff0000;">管理员板块权限设置</a> | <a href="?h=admin&ac=userdh" style="color:#ff0000;">[新]会员之间对话删除</a> | <a href="?h=admin&ac=usergl&mods=jy">被禁言账号管理</a><br>
输入昵称或账号关键字:<input type="text" id="nc" value=""><button type="button" onclick="window.location.href='?h=admin&ac=usergl&mods=cha&ear='+$('#nc').val();">查找</button>

<br>说明: 用户被禁言仍然可以发送消息(仅管理员可见),如需禁止用户请锁定用户<br>为保护会员隐私 我们不提供会员私信消息管理功能,如有需求请登录数据库 在Anlin_chatmess该表中查看, kname为发送者 sname为接收者</div>
</div>

<div class="tip">
<div class="t">关于网站数据备份/转移</div>
<div class="c">
请使用phpmyadmin备份名为Anlin_开头的数据库<br>
Ftp文件备份: <br>
/chaj 目录 为插件数据
<br>
/imgcache目录 为聊天图片存放目录(容量太大不建议备份)<br>
/bbsimg目录 为论坛帖子内容图片存放目录<br>
/tx目录 会员头像存放目录
<br>
/txts目录 网站其它数据存放目录(例如邀请码 虚拟在线会员等)
<br>
/chatimg 聊天室小图与大图存放目录
<br>
/config.php 网站设置
<br>
其它文件可无需备份,如果您倾向于全站备份 你只需更改Anlin_class/ku.php文件中设置你的数据库信息或者重新安装然后通过phpmyadmin恢复数据
</div></div>
<?}?>
<?if($ac=='usergl'){
$c=1;
$quess=$my->query("SELECT user,name,qx FROM Anlin_user where qx='1' or qx='2' limit 50");
while($gk=$my->fetch($quess)){
$c=$c+1;
$gg.='<option value="'.$gk['name'].'">'.$gk['name'].'/'.$gk['user'].'</option>';
if($c>50){break;}
}

echo'<div class="tip">
<div class="t">会员管理</div>
<div class="c">';
$t='';
if($mods=='sh'){$t="WHERE qx='0'";}
if($mods=='mj'){$t="WHERE qx='5'";}
if($mods=='g'){$t="WHERE qx='1' or qx='2'";}
if($mods=='jy'){$t="WHERE qx='4'";}
if($mods=='cha'){
$ear=$_GET['ear'];
$t="where user LIKE '%$ear%' or name LIKE '%$ear%'";}
$o=$my->chax("Anlin_user","$t order by time desc",20);
//sql_ajax全能翻页开始
if(!$_GET['page']||$_GET['page']==''){$_GET['page']='0';}
if($_GET['page']>$my->ce-1){
message('没有内容了');
}
if($_GET['page']<0){
message('没有内容了');
}
//for输出聊天数组
$co=count($o)-1;
echo'

<form action="?h=admin&mods=tjhy" method="post">
账号<input type="text" name="name" ><br>
昵称<input type="text" name="user" ><br>
密码<input type="text" name="pass" ><br>
账号类型:<select name="qx" onchange="if($(this).val()/1==5){$(\'#ggs\').show();}else{$(\'#ggs\').hide();}">
<option value="5">5_马甲账户</option>
<option value="3">3_普通会员</option>
<option value="1">1_超级管理员</option>
<option value="2">2_管理员</option>
</select><b id="ggs">马甲归属账号:<select name="t">
<option value="">所有</option>
'.$gg.'
</select></b>
<input type="submit" value="添加会员">
说明:添加马甲账户可以在聊天页面与同类马甲账户之间一键切换(可以将马甲账户归属于指定管理员下)首次登录使用马甲功能必须刷新一次聊天页面才能出现(在发送按钮旁边),<br>只有超级管理员可以进入网站后台(非必要请不要轻易设置其他账号为超级管理员)<br>管理员只能在聊天页面管理消息或禁言锁定用户(马甲账户只能管理员使用)<a href="?h=admin&ac=admingl" style="color:#ff0000;">管理员板块权限设置</a>
</form><hr>

';

for($i=0;$i<=$co;$i++){
if($o[$i]['t']!=''){$moa='/归属:'.$o[$i]['t'];}else{$moa='';}
echo '
<form action="?h=admin&mods=userpo&id='.$o[$i]['id'].'" method="post">
会员账号:'.$o[$i]['name'].' &nbsp;昵称:<input id="u'.$o[$i]['id'].'" type="text" name="user" value="'.$o[$i]['user'].'" style="display:none;width:100%;"><b onclick="$(\'#u'.$o[$i]['id'].'\').show();$(this).hide();">'.$o[$i]['user'].'</b> &nbsp;权限:
<select name="qx" onchange="if($(this).val()/1==5){$(\'#ggs'.$i.'\').show();}else{$(\'#ggs'.$i.'\').hide();}">
<option value="'.$o[$i]['qx'].'">'.$o[$i]['qx'].'_'.qo($o[$i]['qx']).$moa.'</option>
<option value="0">0_锁定用户</option>
<option value="3">3_普通会员</option>
<option value="4">4_被禁言用户</option>
<option value="5">5_马甲账户</option>
<option value="2">2_管理员</option>
<option value="1">1_超级管理员</option>
</select> <b id="ggs'.$i.'" style="display:none;">马甲归属账号:<select name="t">
<option value="'.$o[$i]['t'].'">'.$o[$i]['t'].'</option>
'.$gg.'
<option value="">所有</option>
</select></b>
 &nbsp;金币:<input name="jb" type="text" value="'.$o[$i]['jb'].'" style="width:50px;"> &nbsp;注册时间:'.date("Y-m-d H:i:s",$o[$i]['time']).' <br>
<input type="submit" value="确认修改"><a onclick="que(\'?h=admin&mods=scuser&name='.$o[$i]['name'].'\')">删除该用户</a>/<a onclick="que(\'?h=admin&mods=scuserchats&name='.$o[$i]['name'].'\')">删除聊天记录(不包含私信)</a>
</form><a href="?h=mess&sname='.$o[$i]['name'].'&wbb=5">私聊链接</a>
<hr>
';
}
echo'

<a href="?h=admin&ac=usergl&mods='.$mods.'&ear='.$_GET['ear'].'&page='.($_GET['page']-1).'">上一页</a>'.($_GET['page']+1).'/'.$my->ce.'<a href="?h=admin&ac=usergl&mods='.$mods.'&ear='.$_GET['ear'].'&page='.($_GET['page']+1).'">下一页</a> 总数: '.$my->zs.'</div></div>';
}
?>

<?if($ac=='admingl'){
if($mods=='chepo'){
$sk=implode(",",$_POST['sk']);
$ne=$_GET['ne'];
if($my->rowk("Anlin_admin where kname='$ne'")<1){
if($my->zeng("Anlin_admin","NULL,'$ne','$sk','0','','$time'")){message("设置成功&");}
}else{
$my->gai("Anlin_admin","n='$sk' where kname='$ne'");
message('设置成功$');
}
}

$larr=$my->query("SELECT id,title FROM Anlin_chatlist order by time desc");
while($f=$my->fetch($larr)){
$lb[$f['id']]='<input name="sk[]" type="checkbox" value="'.$f['id'].'">'.$f['title'].',';
}
function ache($oli=''){
global $lb;
$ll='';
$eoli=explode(',',$oli);
if($oli==''){
foreach($lb as $value){
  $ll.=str_replace('>',' checked="checked">',$value);
 }
}else{
foreach($lb as $key => $value){
if(in_array($key, $eoli)){
  $ll.=str_replace('>',' checked="checked">',$value);
                 }else{
$ll.=$value;
}
  
 }

     }


return $ll;
}

echo'<div class="tip">
<div class="t">普通管理员权限设置</div>
<div class="c">';
$t='';
$t="WHERE qx='2'";
$o=$my->chax("Anlin_user","$t order by time desc",20);
//sql_ajax全能翻页开始
if(!$_GET['page']||$_GET['page']==''){$_GET['page']='0';}
if($_GET['page']>$my->ce-1){
message('暂无管理员 请先添加或设置管理员');
}
if($_GET['page']<0){
message('没有内容了');
}
//for输出聊天数组
$co=count($o)-1;
echo'
<form action="?h=admin&mods=tjhy" method="post">
账号<input type="text" name="name" ><br>
昵称<input type="text" name="user" ><br>
密码<input type="text" name="pass" ><br>
账号类型:<select name="qx" onchange="">
<option value="2">2_管理员</option>
</select>
<input type="submit" value="添加管理员">
</form>说明:默认管理员拥有全部板块管理权限 : 封禁 禁言 删除 发帖 删帖<br>修改为仅指定板块后: 该管理员只能在指定板块中 删除,发帖,禁言,封禁<br>该设置仅能适用于管理员,不是超级管理员<hr>
';
for($i=0;$i<=$co;$i++){
$ad=$my->fetch($my->query("SELECT kname,n FROM Anlin_admin where kname='".$o[$i]['name']."'"));
echo '管理员昵称:'.$o[$i]['user'].' <br>它管理的板块:<form action="?h=admin&ac=admingl&mods=chepo&ne='.$o[$i]['name'].'" method="post">'.ache($ad['n']).'<input type="submit" value="修改"></form><hr>';


}
echo'<a href="?h=admin&ac=admingl&mods='.$mods.'&ear='.$_GET['ear'].'&page='.($_GET['page']-1).'">上一页</a>'.($_GET['page']+1).'/'.$my->ce.'<a href="?h=admin&ac=admingl&mods='.$mods.'&ear='.$_GET['ear'].'&page='.($_GET['page']+1).'">下一页</a> 总数: '.$my->zs.'</div></div>';
}
?>


<?if($ac=='chat'){
echo'<div class="tip">
<div class="t">聊天室管理</div>
<div class="c"><form action="?h=zeng&mods=chatlist" method="post">
输入名称:<input type="text" name="title" >
<input type="submit" value="创建聊天室">
</form>点击id可访问聊天室';
$t='';

$o=$my->chax("Anlin_chatlist","$t order by id",20);
//sql_ajax全能翻页开始
if(!$_GET['page']||$_GET['page']==''){$_GET['page']='0';}
if($_GET['page']>$my->ce-1){
message('没有内容了');
}
if($_GET['page']<0){
message('没有内容了');
}
//for输出聊天数组
$co=count($o)-1;
for($i=0;$i<=$co;$i++){
$op=explode('|',$o[$i]['img']);
$img='<a href="'.$op[0].'">查看封面图</a>,<a href="'.$op[1].'">查看背景图</a>';
if($op[0]==''){$img='暂未上传封面图,<a href="'.$op[1].'">查看背景图</a>';}
if($op[1]==''){$img='<a href="'.$op[0].'">查看封面图</a>,暂未上传背景图';}
if($op[0]==''&&$op[1]==''){$img='暂未上传图片';}

echo '

<form action="?h=admin&mods=chatpo&id='.$o[$i]['id'].'" method="post">
聊天室id: <a href="?h=chat&id='.$o[$i]['id'].'">'.$o[$i]['id'].'</a> | 聊天室名:<input type="text" name="title" value="'.$o[$i]['title'].'"> &nbsp;发言设置:
<select name="qx">
<option value="'.$o[$i]['qx'].'">'.$o[$i]['qx'].'</option>
<option value="0">0_正常发言</option>
<option value="1">1_关闭发言</option>

</select>
 &nbsp;最后发言时间:'.date("Y-m-d H:i:s",$o[$i]['time']).' <br>
<input type="submit" value="确认修改"> <a onclick="que(\'?h=admin&mods=scchat&id='.$o[$i]['id'].'\')">删除聊天室</a> <button type="button" onclick="que(\'?h=admin&mods=scchatm&id='.$o[$i]['id'].'\')">清空聊天消息</button> <button type="button" onclick="$(\'#xww'.$o[$i]['id'].'\').toggle()">修改图片</button>
</form>
<div id="xww'.$o[$i]['id'].'" style="display:none;">
'.$img.'
<form action="?h=admin&mods=chatimg&chaid='.$o[$i]['id'].'&lx=x" enctype="multipart/form-data" method="post"> <input type="file" name="file" accept="image/*"><input type="submit" value="修改封面图"></form><form action="?h=admin&mods=chatimg&chaid='.$o[$i]['id'].'" enctype="multipart/form-data" method="post"> <input type="file" name="file" accept="image/*"><input type="submit" value="修改背景图"></form></div>
<hr>
';
}
echo'<a href="?h=admin&ac='.$_GET['ac'].'&mods='.$mods.'&ear='.$_GET['ear'].'&page='.($_GET['page']-1).'">上一页</a>'.($_GET['page']+1).'/'.$my->ce.'<a href="?h=admin&ac='.$_GET['ac'].'&mods='.$mods.'&ear='.$_GET['ear'].'&page='.($_GET['page']+1).'">下一页</a> 总数: '.$my->zs.'</div></div>';
}



if($ac=='chats'){
if($_GET['ear']!=''){$yin='style="display:none;"';}
echo'<div class="tip">
<div class="t">聊天室消息管理</div>
<div class="c"><div '.$yin.'>
按条件删除: <button onclick="que(\'?h=admin&mods=scchats&ts=30\')">删除30天以前的消息</button>
<button onclick="que(\'?h=admin&mods=scchats&ts=60\')">删除60天以前的消息</button>
<form action="?"><input name="h" type="hidden" value="admin"><input name="mods" type="hidden" value="scchats">指定天数:<input name="ts" type="text" value=""><input type="submit" value="删除"></form></div>非单条删除无法删除消息中的图片文件,如需删除过去的消息图片请至全局设置中删除
<hr>

';
$ear=$_GET['ear'];
$t='';
if($ear!=''){
$t="where kname='$ear' or kuser='$ear'";
}
$o=$my->chax("Anlin_chat","$t order by time desc",20);
//sql_ajax全能翻页开始
if(!$_GET['page']||$_GET['page']==''){$_GET['page']='0';}
if($_GET['page']>$my->ce-1){
message('未找到数据');
}
if($_GET['page']<0){
message('没有内容了');
}
//for输出聊天数组
$co=count($o)-1;
for($i=0;$i<=$co;$i++){
echo '
'.$o[$i]['kuser'].':'.ubb(preg_replace("/\[img\]\.\/imgcache([^\"].+?)\[\/img\]/is",'<img src="./imgcache\\1" style="max-width:200px;">',$o[$i]['content'])).' <br>
所属聊天室id: <a href="?h=chat&id='.$o[$i]['chaid'].'">'.$o[$i]['chaid'].'</a> | 账号:'.$o[$i]['kname'].' | 
 &nbsp;发言时间:'.date("Y-m-d H:i:s",$o[$i]['time']).' <br>
<button onclick="que(\'?h=admin&mods=scchats&id='.$o[$i]['id'].'\')">删除</button>
<hr>
';
}
echo'<a href="?h=admin&ac='.$_GET['ac'].'&mods='.$mods.'&ear='.$_GET['ear'].'&page='.($_GET['page']-1).'">上一页</a>'.($_GET['page']+1).'/'.$my->ce.'<a href="?h=admin&ac='.$_GET['ac'].'&mods='.$mods.'&ear='.$_GET['ear'].'&page='.($_GET['page']+1).'">下一页</a> 总数: '.$my->zs.'</div></div>';
}
?>




<script>
function que(url){
var g=confirm('确认删除吗？数据删除无法恢复');
if(g){window.location.href=url;}else{return false;}
}
</script>



</div>

<div id="both"></div>
<style>
input[type='submit']{background:#ff0000;color:#fff;}
</style>
</body></html>