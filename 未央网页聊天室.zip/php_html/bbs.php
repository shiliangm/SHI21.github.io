<?php 

/**安林网络bbs内容20wl.cn 
wbb请求
Bbs.php?id=
**/
include './Anlin_class/define.php';
include './Anlin_class/ubb.php';
include './config.php';
$time=time();
function kie($no,$no2){
global $time;
setcookie($no,$no2,$time+86400);}
$my=new mys;
$id=htmlx($_GET['id']);
//当前用户信息开始
$name=htmlx($_COOKIE['name']);
if($name!=''){
$u=$my->cha("Anlin_user","name='".$name."' and pass='".htmlx($_COOKIE['pass'])."'");

if($u['name']==''){exit(UTF8.'<center><br><br><br><br><br><br><br><br><br>您的登录信息已失效,请登录后再进行访问<a href="?">返回</a></center>');}
}





$l=$my->fetch($my->query("SELECT*FROM Anlin_chatbbs WHERE id='$id'"));
if($l['id']!=''){

$my->gai("Anlin_chatbbs","d=d+1 WHERE id='$id'");

}else{$l['title']='帖子不存在或已被删除';}
$btooo=$l['title'];

/**回复列表数据**/
$t=$_GET['t'];
$gun=$_GET['gun'];
if($gun=='1'||$gun==''){
$tt=' order by time desc';
}
if($gun=='2'){
$tt=' order by time';
}
if($gun=='3'){
$tt=" and kname='$name' order by time desc";
}
$o=$my->chax("Anlin_chatbbshui",'where bbsid=\''.$id.'\''.$tt.'',$a['sl']);
if($_GET['gun']!=''){
if(!$_GET['page']||$_GET['page']==''){$_GET['page']='0';}
if($_GET['page']>$my->ce-1){exit();}
if($_GET['page']<0){exit('pagea');}
}
$co=count($o)-1;
for($i=0;$i<=$co;$i++){
if($o[$i]['qx']=='4'&&$u['qx']=='3'){continue;}
if($o[$i]['kname']==$name){
$float='ri';
$sty='style=\'text-align:right;\'';
$lin='lin2 ri';
//$hon="pph('l".$o[$i]['id']."','".$o[$i]['id']."','');";
}else{
$float='le';
$sty='';
$lin='lin le';

}
$hon="pph('l".$o[$i]['id']."','".$o[$i]['id']."','');bspo('".$o[$i]['id']."','".$o[$i]['kname']."','".$o[$i]['kuser']."');";
$sl='<b id="l'.$o[$i]['id'].'" onclick="'.$hon.'">回复('.$my->rowk("Anlin_chatbbshui where y='".$o[$i]['id']."'").')</b>';

$ob=$my->fetch($my->query("SELECT name,qx,tx FROM Anlin_user WHERE name='".$o[$i]['kname']."' limit 1"));

if($ob['qx']=='0'){$ssss='已';}else{$ssss='';}
if($u['qx']=='1'||$u['qx']=='2'){
$bsl='<b onclick="getts(\''.LL.'?h=zeng&mods=suo&name='.$o[$i]['kname'].'\');huan(this)">'.$ssss.'封禁</b> <b onclick="getts(\''.LL.'?h=zeng&mods=chatbbsde&id='.$o[$i]['id'].'\',\'id'.$o[$i]['id'].'\')">删</b> ';
if($o[$i]['kname']==$u['name']){
$bsl='<b onclick="getts(\''.LL.'?h=zeng&mods=chatbbsde&id='.$o[$i]['id'].'\',\'id'.$o[$i]['id'].'\')">删</b>';
}
}else{$bsl='';}

$tu5=$ob['tx'];
if($tu5==''){$tu5='./tx/null.png';}
if($o[$i]['sname']!=''){
$tos='<b style="border-bottom:1px #ff0000 dashed;">回复 '.$o[$i]['sname'].' (<a id="xl'.$o[$i]['id'].'" onclick="pph(\'xl'.$o[$i]['id'].'\',\''.$o[$i]['y'].'\',\'\');">查看该楼</a>)</b><br>';
}else{$tos='';}
if($ob['qx']=='1'||$ob['qx']=='2'){$gl='<b style="background:#2fdd60;">管理员</b> ';}else{$gl='';}
$ll.='<div id="id'.$o[$i]['id'].'"><div class="lined">'.date("Y-m-d H:i:s",$o[$i]['time']).'</div><div class="linet" '.$sty.'>'.$bsl.$gl.'<a onclick="user(\''.$o[$i]['kname'].'\');">'.$o[$i]['kuser'].'</a>'.$sl.'</div><div class="name '.$float.'"><img src="'.$tu5.'" onclick="user(\''.$o[$i]['kname'].'\');"></div><div id="d'.$o[$i]['time'].'" class="line '.$lin.'">'.$tos.ubb($o[$i]['content']).'</div></div><div id="both" style="margin-bottom:10px;"></div>';


}
//$ll.='<!--id'.$idx.'id-->';
//for数组结束
if($t!=''){
if($name!=''){

$mesl=$my->rowk("Anlin_chatmess WHERE y!='1' and sname='$name'");
$ll.='<!--ms'.$mesl.'ms-->';
}else{$ll.='<!--ms0ms-->';}
$ll.='<!--zs'.$my->zs.'zs-->';
exit($ll);
}
$wbb=$_GET['wbb'];
//$url=$_SERVER['REQUEST_URI'];
$url=LL.'?'.$_SERVER['QUERY_STRING'];
echo'<html><head>';
echo UTF8;
include './php_html/global/head.php';
?>
var aj=null;
var tyz='<?=$time?>';
var gunn='1';
var page=0;
function get(){
//setTimeout("ju()",1000);
}

function getbbs(pa){

var url='<?=$url?>&t='+tyz+'&gun='+gunn;
if(pa!=''){url=url+'&page='+(page/1+1);
$("#tss").html('正在加载...');
$("#tss").attr('onclick','');
}else{page=0;}
aj=$.ajax({
       url:url, 
       type:'get',        
       dataType:'text',    
       data:'',
       //async:false,
       success:function(data){
var time = Date.parse(new Date());
time=(time/1000);
tyz=time;
var datass=data.replace(/<!--(.*?)-->/g,'');
if(pa!=''){if(datass==''){$("#tss").hide();ts('没有更多了');}}
if(data!=''){
var msshu=data.indexOf('ms-->');
if(msshu==-1){return false;}
var mess=data.substring(data.indexOf('<!--ms')+6,msshu);
if(mess/1>0){$('#mstsxxx').attr('class','right blink');
$('#msts').attr('class','right blink');
}else{
$('#mstsxxx').attr('class','right');$('#msts').attr('class','right');}

$("#mess").text(mess);

if(datass!=''){

if(pa!=''){
$("#listhui").append(datass);
page=page+1;
$("#tss").html('加载更多('+(page/1+1)+'/<?=$my->ce?>)');
$("#tss").attr('onclick',"getbbs('Pa')");
}else{
ts('已刷新');
$("#listhui").html(datass);
$('#bbszs').text(data.substring(data.indexOf('<!--zs')+6,data.indexOf('zs-->')));
}


}

}
     }
     });
}
<?if($wbb==''){?>
parent.tshide();<?}else{?>
function closeIFrame(){
        $("iframe").attr("src","javascript:false");
        $('#youriframeid').remove();
xu();

getwml('<?=LL?>?h=messlist','messlist','ms','');
    }
function tshide(){
        
        $('#frts').hide();

    }
<?}?>
</script>
</head><body>
<?php if(ua()){include './php_html/global/load.html';}else{include './php_html/global/loadpc.html';}

?>
<?php 

include './php_html/global/login.php';
?>
<div id="usermm" style="position:fixed;overflow-y:scroll;height:100%;top:0;left:0;right:0;max-width:600px;margin:0 auto;background:#fff;z-index:1000;display:none;">

</div>
<div class="header" style="">
<div class="left"><a style="" id="loginss" onclick="<?if($wbb!=''){?>history.back();<?}else{?>parent.closeIFrame();<?}?>">⬅︎</a></div>
<div class="center" style=""><?=$l['title']?><div style="font-size:65%;">热度<b id="userzx" style="color:#ff0000;"><?=$l['d']?></b>°</div></div>
<div id="msts<?if($wbb==''){?>xxx<?}?>" class="right" onclick="<?if($wbb==''){?>$('#msts',parent.document).trigger('click');parent.closeIFrame();<?}?>"><img class="ico_m" src="./bqimg/mess.gif">(<b id="mess" style="font-size:80%">0</b>)</div>
<div id="both"></div>

</div>

<div id="list" style="height:100%;-webkit-overflow-scrolling : touch;overflow-y:scroll;position:absolute;left:0;right:0;padding:0;margin:0 auto;width:100%;" onscroll="imgkj()" onclick="$('#cd').children().hide();">
<?if($u['qx']=='2'){?>
<center style="color:#983597">#管理: <a id="f123" href="javascript:void(0);" onclick="getts('<?=LL?>?h=zeng&mods=bbsde&id=<?=$id?>','f123')" style="color:#ff0000;">删除该帖子(谨慎操作！无法恢复)</a> | <button type="button" onclick="$('#fbbs').toggle();">发新帖</button></center>
<div id="fbbs" style="display:none;width:95%;margin:0 auto;">
<form action="" method="post" id="ppoxxxx" enctype="multipart/form-data">
标题: <input id="fb1xxxx" type="text" name="title" style="width:60%;">
<br>
内容:<br><textarea id="fb2xxxx" name="content" style="width:100%;height:250px;"></textarea><br>你可以在内容中插入代码: [size=30]字体大小[/size] 链接: [url=链接地址]标题[/url] 
<br>
图片:  <input type="file" name="file" id="fb3xxxx" accept="image/*">
<br>
初始热度 : <input type="text" name="d" value="<?=rand(5,30)?>">
<br><input id="bxbo" type="button" value="发布" onclick="bbsgoxxxx('bxbo',this.value);"> 
</form>
</div>

<script>function bbsgoxxxx(id,va){


if($("#fb1xxxx").val()==''){
ts("标题不能为空");
return false;
}
var p="bbsgoxxxx('"+id+"','"+va+"')";
$("#"+id).attr('onclick','');
$("#"+id).val(va+'中...');
setTimeout(function(){if($("#"+id).val()==va+'中...'){
ts('服务器繁忙,请重试');
$("#"+id).val(va);$("#"+id).attr('onclick',p);}},20000);

    var formxxxx = new FormData(document.getElementById("ppoxxxx"));

    $.ajax({
          url:'<?=LL?>?h=zeng&mods=bbsgo&chaid=<?=$l['chaid']?>',
          type:'post',
          dataType:'text', 
          data:formxxxx,
          cache: false,            
          processData: false,      
          contentType: false,      
          success:function(data){
          ts(data);
if(data.indexOf("请登录")!=-1){$("#logink").show();}
if(data.indexOf("成功")!=-1){
$("#fb3xxxx").val('');
$("#fb1xxxx").val('');
$("#fb2xxxx").val('');
}
$("#"+id).attr('onclick',p);
$("#"+id).val(va);

          },
          error:function(e){
              ts('服务器繁忙,请重试！');
$("#"+id).attr('onclick',p);
$("#"+id).val(va);
           }
    });
}</script>
<?}?>
<div style="line-height:30px;padding:10px 10px 10px 10px;"><h2><?=btubb($l['title'])?></h2><?=ubb($l['content'])?></div>
<div id="pph" style="z-index:200;background:rgba(255,255,255,.9);position:absolute;width:75%;height:300px;border:3px #ff0000 solid;overflow-y:scroll;display:none;"><a onclick="$('#pph').hide();$('#y').val('');$('#aname').text('');$('#sname').val('');" style="background:#ff0000;color:#fff;">关闭</a><div id="lzhf">load...</div></div>
<div id="linxx" style="line-height:30px;background:#fff;padding:1px 8px 1px 8px;border-top:3px #ff4500 solid;">回复列表<select onchange="gunn=this.value;getbbs('');"><option value="1">最新</option><option value="2">最早</option><option value="3">只看我</option></select>: <font style="float:right;">共<b id="bbszs"><?=$my->zs?></b>条回复 | <a href="javascript:void(0)" onclick="getbbs('')">刷新回复</a></font></div>
<div id="both"></div>
<div id="listhui"><?=$ll?></div>
<div style="text-align:center;line-height:33px;"><a id="tss" onclick="getbbs('paG')">加载更多</a></div>
</div>
<style>
#list img{max-width:100%;}
</style>

<div class="bottom">
<form method="post" action="" enctype="multipart/form-data" id="J-add-form">
  <div class="ifu">
<li style="width:10%;float:left;"><input type="button" class="xxx" value="✕" onclick="$('#textcon').html('');$('#y').val('');$('#sname').val('');$('#cfile').val('');$('#img').attr('src','');$('#aname').text('输入内容');$('#pph').hide();"></li>
<li style="width:70%;float:left;position:relative;"><div id="aname" style="height:42px;line-height:40px;">输入回复内容</div><div id="textcon" style="-moz-user-modify: read-write-plaintext-only;-webkit-user-modify: read-write-plaintext-only;position:absolute;top:0;left:0;overflow-y:auto;background-color:rgba(255,255,255,.8);" onclick="$('#aname').html('');" onblur="wapd();"></div></li><textarea id="content" placeholder="输入内容" type="text" name="content" style="display:none"></textarea>
 <input type="file" name="file" id="cfile" accept="image/*" onchange="show(this);" style="display:none;">
<input type="hidden" id="y" name="y" value="">
<input type="hidden" id="sname" name="sname" value="">
<li style="width:20%;float:left;"><input type="button" id="Xx" value="发送" onclick="bbspost(this.id,this.value);"></li></div>
</form>
<script>
function pph(ttha,lid,ro){
if(!ro||ro==''){
$('#pph').show();
var ttoop=$("#list").scrollTop()+$('#'+ttha).offset().top-300;
if(ttoop<10){ttoop=10;}
$('#pph').css({'left':'50px','top':ttoop});
}
$('#lzhf').text('正在加载...');
getxs('<?=LL?>?h=bbshui&id=<?=$id?>&y='+lid,'lzhf');
}
function bspo(lid,sname,us){

$('#y').val(lid);
$('#sname').val(sname);
$('#aname').text('回复'+us);
//foc();
}
function bbspost(id,va){

var zcon=$("#textcon").html();
if($("#cfile").val()==''){
if(zcon==''||zcon=='<br>'){if(jimg==''){ts('请输入内容');return false;}}
}
var p="bbspost('"+id+"','"+va+"')";
$("#"+id).attr('onclick','');
$("#"+id).val(va+'中...');
setTimeout(function(){if($("#"+id).val()==va+'中...'){
ts('服务器繁忙,请重试');
$("#"+id).val(va);$("#"+id).attr('onclick',p);}},20000);

$('#cd').children().hide();

zcon=zcon.replace(/<img src="(.*?)"(.*?)>/g,"\[img\]$1\[\/img\]");
zcon=zcon.replace(/<img src='(.*?)'(.*?)>/g,"\[img\]$1\[\/img\]");

zcon=zcon.replace(/<img style="(.*?)" src="(.*?)">/g,"\[img\]$2\[\/img\]");
zcon=zcon.replace(/<br>/g,"\[br\]");
if(ua.indexOf('WebKit')==-1){
zcon=zcon.replace(/<div>/g,"");
zcon=zcon.replace(/<\/div>/g,"");
}

var xuan=$("#xinput").val();
if(xuan!=''){
zcon='[fontxc'+xuan+']'+zcon+'[/fontxc'+xuan+']';
}else{

zcon='[font=color:'+$("#textcon").css("color").replace(/ /g,'')+';]'+zcon;
zcon+='[/font]';

}
$("#content").val(zcon);
    var formData = new FormData(document.getElementById("J-add-form"));
if(jimg!=''){
formData.append("file",jimg);
}
    $.ajax({
          url:'<?=LL?>?h=zeng&mods=bbshui&bbsid=<?=$id?>',
          type:'post',
          dataType:'text', 
          data:formData,
          cache: false,            
          processData: false,      
          contentType: false,      
          success:function(data){
          ts(data);
if(data.indexOf("请登录")!=-1){$("#logink").show();}
if(data.indexOf("成功")!=-1){
js();
$("#content").val('');
$("#textcon").html('');
$("#cfile").val('');
$("#img").attr('src','');
$("#y").val('');
$('#aname').text('');$('#sname').val('');
jimg='';
getbbs('');
$('#pph').hide();
$('#linxx')[0].scrollIntoView();
}
$("#"+id).attr('onclick',p);
$("#"+id).val(va);

          },
          error:function(e){
              ts('服务器繁忙,请重试！');
$("#"+id).attr('onclick',p);
$("#"+id).val(va);
           }
    });
}


if('<?=$my->zs;?>'=='0'){$('#aname').html('抢沙发');}
foc();
if(ua.indexOf('Window')!=-1){
document.onkeydown = function (e) {
            if (!e) e = window.event;
            if ((e.keyCode || e.which) == 13) {
if (!e.shiftKey){
e.cancelBubble=true;

e.preventDefault();

e.stopPropagation();
                chatpost('Xx','发送');}
            }
        }
}
if(ua.indexOf('WebKit')==-1){$("#textcon").attr('contenteditable','true');}
setTimeout("getbbs('');",1000);
</script>
<div id="both"></div>
<?php 
include './php_html/global/form.php';
echo'</div>';
$clist=$my->fetch($my->query("SELECT img FROM Anlin_chatlist where id='".$l['chaid']."'"));
$niko=explode('|',$clist['img']);
if($niko[1]!=''){
echo'<script>$(document).ready(function(){$("html").css("background-image","url('.$niko[1].')");
});</script>';
}
include './php_html/global/bottom.php';?>
</body>
</html>