<?php 

/**安林网络bbs内容20wl.cn 
wbb请求
Bbs.php?id=
**/
include './Anlin_class/define.php';
include './Anlin_class/ubb.php';
include './config.php';
$time=time();
function kie($no,$no2){
global $time;
setcookie($no,$no2,$time+86400);}
$my=new mys;
$id=htmlx($_GET['id']);
//当前用户信息开始
$name=htmlx($_COOKIE['name']);
if($name!=''){
$u=$my->cha("Anlin_user","name='".$name."' and pass='".htmlx($_COOKIE['pass'])."'");
if($u['name']==''){exit(UTF8.'<center><br><br><br><br><br><br><br><br><br>您的登录信息已失效,请登录后再进行访问<a href="?">返回</a></center>');}
}
$y=htmlx($_GET['y']);
$louc=$my->fetch($my->query("SELECT*FROM Anlin_chatbbshui where id='$y'"));

$tt=" and y='".$y."'";
$o=$my->chax("Anlin_chatbbshui",'where bbsid=\''.$id.'\''.$tt.' order by time desc',$a['sl']);
if($_GET['gun']!=''){
if(!$_GET['page']||$_GET['page']==''){$_GET['page']='0';}
if($_GET['page']>$my->ce-1){exit('');}
if($_GET['page']<0){exit('pagea');}
}
$co=count($o)-1;
for($i=0;$i<=$co;$i++){
if($o[$i]['qx']=='4'&&$u['qx']=='3'){continue;}
if($o[$i]['kname']==$name){
$float='ri';
$sty='style=\'text-align:right;\'';
$lin='lin2 ri';
//$hon="pph('l".$o[$i]['id']."','".$o[$i]['id']."',1);";
}else{
$float='le';
$sty='';
$lin='lin le';

}
$hon="pph('l".$o[$i]['id']."','".$o[$i]['id']."','1');bspo('".$o[$i]['id']."','".$o[$i]['kname']."','".$o[$i]['kuser']."');";
$sl='<b id="l'.$o[$i]['id'].'" onclick="'.$hon.'">回复('.$my->rowk("Anlin_chatbbshui where y='".$o[$i]['id']."'").')</b>';

$ob=$my->fetch($my->query("SELECT name,qx,tx FROM Anlin_user WHERE name='".$o[$i]['kname']."' limit 1"));

if($ob['qx']=='0'){$ssss='已';}else{$ssss='';}
if($u['qx']=='1'||$u['qx']=='2'){
$bsl='<b onclick="getts(\''.LL.'?h=zeng&mods=suo&name='.$o[$i]['kname'].'\');huan(this)">'.$ssss.'封禁</b> <b onclick="getts(\''.LL.'?h=zeng&mods=chatbbsde&id='.$o[$i]['id'].'\',\'id'.$o[$i]['id'].'\')">删</b> ';
if($o[$i]['kname']==$u['name']){
$bsl='<b onclick="getts(\''.LL.'?h=zeng&mods=chatbbsde&id='.$o[$i]['id'].'\',\'id'.$o[$i]['id'].'\')">删</b>';
}
}else{$bsl='';}

$tu5=$ob['tx'];
if($tu5==''){$tu5='./tx/null.png';}

if($ob['qx']=='1'||$ob['qx']=='2'){$gl='<b style="background:#2fdd60;">管理员</b> ';}else{$gl='';}
$ll.='<div id="id'.$o[$i]['id'].'"><div class="lined" style="color:#000;">'.date("Y-m-d H:i:s",$o[$i]['time']).'</div><div class="linet" '.$sty.'>'.$bsl.$gl.'<a onclick="user(\''.$o[$i]['kname'].'\');">'.$o[$i]['kuser'].'</a>'.$sl.'</div><div class="name '.$float.'"><img src="'.$tu5.'" onclick="user(\''.$o[$i]['kname'].'\');"></div><div id="d'.$o[$i]['time'].'" class="line '.$lin.'">'.ubb($o[$i]['content']).'</div></div><div id="both" style="margin-bottom:10px;"></div>';


}
if($ll!=''){echo'<center>该楼层共'.$my->zs.'条回复</center>';}
echo '<div style="border-bottom:2px #ff0000 solid;">原文:<b>'.$louc['kuser'].'</b>:'.ubb($louc['content']).'</div>'.$ll;
if($ll==''){exit('<center>暂无回复</center>');}
if($_GET['page']/1!='0'){
$back='<a onclick="$(\'#lzhf\').text(\'正在加载...\');getxs(\''.LL.'?h=bbshui&id='.$id.'&y='.$y.'&page='.($_GET['page']-1).'\',\'lzhf\');">上一页</a>';
}
if($my->ce-1>$_GET['page']){
$next='<a onclick="$(\'#lzhf\').text(\'正在加载...\');getxs(\''.LL.'?h=bbshui&id='.$id.'&y='.$y.'&page='.($_GET['page']+1).'\',\'lzhf\');">下一页</a>';}

echo'<br><center>'.$back.' 页数:'.($_GET['page']+1).'/'.$my->ce.' '.$next.'</center>';

?>