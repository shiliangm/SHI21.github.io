<?php 

/**安林网络聊天室列表20wl.cn 
chat.php?id=聊天室id
**/
include './Anlin_class/define.php';
include './Anlin_class/ubb.php';
include './config.php';
$time=time();
function kie($no,$no2){
global $time;
setcookie($no,$no2,$time+86400);}
$my=new mys;
$id=htmlx($_GET['id']);
if($id==''){$id=1;}//开发者测试时使用

$t=htmlx($_GET['t']);
//当前用户信息开始
$name=htmlx($_COOKIE['name']);
//if($name==''){exit(UTF8.'暂时关闭');}
if($name!=''){
$u=$my->cha("Anlin_user","name='".$name."' and pass='".htmlx($_COOKIE['pass'])."'");
}
if($u['tx']==''){$u['tx']='./tx/null.png';}
//当前房间数据开始
$clist=$my->cha("Anlin_chatlist","id='$id'");
$y=$clist['y'];
$btooo=$clist['title'];
//更新在线数

if($clist['time']+$a['zx']<$time){
$my->gai("Anlin_chatlist","y='',time='$time' WHERE id='$id'");

}
//更新在线数结束

if($u['user']!=''){//user 

if(!strstr($y,'"'.$u['user'].'"')){//str 
if($u['tx']==''){$u['tx']='./tx/null.png';}

$my->gai("Anlin_chatlist","y='".$y.'<'.$u['name'].'"'.$u['user'].'"'.$u['tx'].'"'.$time.'>'."' WHERE id='$id'");//<name"用户名"头像"时间>
}//str

}//user_error



if($clist['id']==''){exit('404');}
//在线会员表
$ex=explode('>',str_replace('<','',$y));
shuffle($ex);
$xn=@file_get_contents('./txts/#zaix.txt');//虚拟在线会员文件
if($xn!=''){
$xn=str_replace(' ','',$xn);
$xn=str_replace(array("\r", "\n", "\r\n"),'',$xn);
$ex0=explode('>',str_replace('<','',$xn));
$xns=count($ex0)-2;

$ranx=rand(0,ceil($xns/100*5));
shuffle($ex0);
}
$ex=array_merge($ex,$ex0);
$zxs=count($ex)-2;//在线数
if($xns!=''&&$xns>5){$zxs=$zxs-$ranx;}
if($_GET['zx']==1){
if($a['zxlist']==1){
$u_list='<li style="width:20px;visibility:hidden;"><img src="./tx/null.png"><div class="ustext">&nbsp;</div></li>';}
for($i=0;$i<=$zxs;$i++){//for 
$ex2=explode('"',$ex[$i]);
if($ex2[2]==''){continue;}
if($ex2[2]=='tx'){$ex2[2]='./tx/null.png';}
if($u['qx']=='1'||$u['qx']=='2'){$on=' onclick="user(\''.$ex2[0].'\');"';}else{$on='';}
$u_list.='<li'.$on.'><img src="'.$ex2[2].'"><div class="ustext">'.$ex2[1].'</div></li>';

}//for 
if($a['zxlist']==1){
$u_list.='<li style="width:20px;visibility:hidden;"><img src="./tx/null.png"><div class="ustext">&nbsp;</div></li>';}
exit('<!--us'.$u_list.'us-->');
}
//在线会员表结束

//聊天列表数据开始
if(is_numeric($t)){
if($_COOKIE['t']==$t){exit();}kie('t',$t);

$t=$_COOKIE['cf'];
if($t==''){$t=$time;}
}
$tt=" and time>".$t;
if($t=='@'){$tt='';}
if($t=='gun'){$tt=" and time<".htmlx($_GET['gun']);}
if($t==''){$tt='';}
//@新消息
if($name!=''){
$at=$my->fetch($my->query("SELECT * FROM Anlin_chat where sname='".$u['name']."' and chaid='$id' and y!='0' order by time desc limit 0,1"));
if($at['kuser']!=''){
$aite='<!--at<a onclick="getts(\''.LL.'?h=zeng&mods=yidu&yy='.$at['y'].'&id='.$at['id'].'\',\'ait\');" class="leftbtn fobtn">移除</a><a onclick="by(\'d'.$at['y'].'\').scrollIntoView();" class="fobtn focen"><b>'.$at['kuser'].'回复了你:</b>'.ubb(str_replace('回复:'.$u['user'].' ','',$at['content'])).'</a><a class="rightbtn fobtn" onclick="anlin(\''.LL.'?h=mess&sname='.$at['kname'].'\')">私信T</a>at-->';

}
}
//@新消息

$o=$my->chax("Anlin_chat",'where chaid='.$id.$tt.' order by time desc',$a['sl']);
//sql_ajax全能翻页开始
if($_GET['gun']!=''){
if(!$_GET['page']||$_GET['page']==''){$_GET['page']='0';}
if($_GET['page']>$my->ce-1&&$t==''){exit('{"error":"page"}');}
if($_GET['page']<0){exit('pagea');}
}
//for输出聊天数组
$co=count($o)-1;
for($i=$co;$i>=0;$i--){
if($i==$co){$gun=$o[$i]['time'];}
if($o[$i]['qx']=='4'&&$u['qx']=='3'){continue;}
if($o[$i]['kname']==$name){
$float='ri';
$sty='style=\'text-align:right;\'';
$lin='lin2 ri';
$sl='';

}else{
$float='le';
$sty='';
$lin='lin le';
$sl='<b onclick="anlin(\''.LL.'?h=mess&sname='.$o[$i]['kname'].'\')">私信</b>';
}
$ob=$my->fetch($my->query("SELECT name,qx,tx FROM Anlin_user WHERE name='".$o[$i]['kname']."' limit 1"));
if($ob['qx']=='4'){$ssjj='已';}else{$ssjj='';}
if($ob['qx']=='0'){$ssss='已';}else{$ssss='';}
if($u['qx']=='1'||$u['qx']=='2'){
$bsl='<b onclick="getts(\''.LL.'?h=zeng&mods=suo&name='.$o[$i]['kname'].'\');huan(this)">'.$ssss.'封禁</b> <b onclick="getts(\''.LL.'?h=zeng&mods=jy&name='.$o[$i]['kname'].'\');huan(this)">'.$ssjj.'禁言</b> <b onclick="getts(\''.LL.'?h=zeng&mods=chatde&id='.$o[$i]['id'].'\',\'id'.$o[$i]['id'].'\')">删</b> ';
if($o[$i]['kname']==$u['name']){
$bsl='<b onclick="getts(\''.LL.'?h=zeng&mods=chatde&id='.$o[$i]['id'].'\',\'id'.$o[$i]['id'].'\')">删</b>';
}
}else{$bsl='';}

$tu5=$ob['tx'];
if($tu5==''){$tu5='./tx/null.png';}

if($ob['qx']=='1'||$ob['qx']=='2'){$gl='<b style="background:#2fdd60;">管理员</b> ';}else{$gl='';}
$ll.='<div id="id'.$o[$i]['id'].'"><div class="lined">'.date("Y-m-d H:i:s",$o[$i]['time']).'</div><div class="linet" '.$sty.'>'.$bsl.$gl.'<a onclick="user(\''.$o[$i]['kname'].'\');">'.$o[$i]['kuser'].'</a>'.$sl.'</div><div class="name '.$float.'"><img src="'.$tu5.'" onclick="aite(\''.$o[$i]['kuser'].'\',\''.$o[$i]['kname'].'\',\''.$o[$i]['time'].'\');"></div><div id="d'.$o[$i]['time'].'" class="line '.$lin.'">'.ubb($o[$i]['content']).'</div></div><div id="both" style="margin-bottom:10px;"></div>';
if($i==$co){
$idx=$o[$i]['id'];}
}
//for数组结束
if($_GET['gun']==''){//gun
if($ll!=''){
kie('cf',$time);
if($t!=''){//t
//
}//t
}
$ll.='<!--zx'.$zxs.'xz-->'.$aite;
$ll.='<!--id'.$idx.'id-->';
//帖子显示
if($_SESSION['bbs']+$a['bbspl']<$time&&$a['bbspl']<9999){
$_SESSION['bbs']=$time;
if($a['bbspx']=='1'){$px='order by time desc';}
if($a['bbspx']=='2'){$px='order by d desc';}
if($a['bbspx']=='3'){$px='order by time';}
if($a['bbspx']=='4'){$px='order by h desc';}
$bque=$my->query("SELECT id,title FROM Anlin_chatbbs WHERE chaid='".$id."' or chaid='0' $px limit ".$a['bbsts']);
while($rb=$my->fetch($bque)){$bbs.='<div class="bbs1"><a onclick="$(this).parent().fadeOut();">❌</a><b onclick="anlin(\''.LL.'?h=bbs&id='.$rb['id'].'\')">'.btubb($rb['title']).'</b></div>';}
$ll.='<!--BS'.$bbs.'
<script>$("#bbs").animate({left:"30px",},"slow");
$("#bbs").animate({left:"8px",opacity:"1",},"slow");</script>
BS-->';
}


//帖子结束

//消息数量
if($name!=''){
$mesl=$my->rowk("Anlin_chatmess WHERE y!='1' and sname='$name'");
$ll.='<!--ms'.$mesl.'ms-->';
}else{$ll.='<!--ms0ms-->';}

//消息数量
}//gun


if($t!=''){
exit($ll);
}
$_SESSION['bbs']='0';
$url=LL.'?'.$_SERVER['QUERY_STRING'];
echo'<html><head>';
echo UTF8;
include './php_html/global/head.php';
?>

function huan(cc){
if(cc.innerHTML.indexOf('已')!=-1){cc.innerHTML=cc.innerHTML.replace(/已/g,'');}else{
cc.innerHTML='已'+cc.innerHTML;
}

}
var aj=null;
var tyz='<?=$time?>';
var xid='';//请求成功时获取一段该数据唯一标识的id,尽管ajax会产生各种停顿和延迟并发卡顿等bug 都将不再重复获取数据
function get(){

var url='<?=$url?>&t='+tyz;
aj=$.ajax({
       url:url, 
       type:'get',        
       dataType:'text',    
       data:'',
       //async:false,
       success:function(data){

var time = Date.parse(new Date());
time=(time/1000);
tyz=time;
if(data!=''){
var zxshu=data.indexOf('xz-->');
if(zxshu==-1){return false;}
var datass=data.replace(/<!--(.*?)-->/g,'');
$("#userzx").text(data.substring(data.indexOf('<!--zx')+6,zxshu));
var mess=data.substring(data.indexOf('<!--ms')+6,data.indexOf('ms-->'));
if(mess/1>0){$('#msts').attr('class','right blink');}else{$('#msts').attr('class','right');}
$("#mess").text(mess);
$("#mas").text(mess);
var aite=data.substring(data.indexOf('<!--at')+6,data.indexOf('at-->'));
if(data.indexOf('<!--at')==-1){aite='';}
if(aite!=''){
$("#ait").html(aite);
$("#ait").show();
}

var bbst=data.substring(data.indexOf('<!--BS')+6,data.indexOf('BS-->'));
if(data.indexOf('<!--BS')==-1){bbst='';}
if(bbst!=''){
$("#bbs").html(bbst);
$("#bbs").show();

}

if(datass!=''){
var sxid=data.substring(data.indexOf('<!--id')+6,data.indexOf('id-->'));

if(xid!=sxid){
$("#list").append(datass);
xid=sxid;
$(".linss").remove();
}



}

}
    
       dbb();}
     });


}
function closeIFrame(){
        $("iframe").attr("src","javascript:false");
        $('#youriframeid').remove();
xu();

getwml('<?=LL?>?h=messlist','messlist','ms','');
    }
function tshide(){
        
        $('#frts').hide();

    }
</script>
<?php 

if(ua()){include './php_html/global/load.html';}else{include './php_html/global/loadpc.html';}?>
<style>
.bbs1{line-height:22px;border-radius:4px;margin-top:2px;padding:1px 8px 0px 0px;background:#fff;text-align:left;}.bbs1 img{vertical-align:middle;}.bbs1 a{display:inline-block;width:20px;padding-right:8px;padding-left:8px;}
</style>
</head><body style="">

<?php 
include './php_html/global/login.php';
?>

<div class="header">

<div class="left"><a style="<?php 
if($u['name']!='') echo'display:none;';?>" id="nologin" onclick="$('#logink').show();"><img class="ico_m" src="./bqimg/user.png"></a><a style="<?php 
if($u['name']=='') echo'display:none;';?>" id="yeslogin" onclick="user('')"><img class="ico_m" src="./bqimg/user.png"></a></div>
<div class="center" onclick="getwml('<?=$url?>&zx=1','userlistb','us','userlist');$('#X').toggle();$('#S').toggle();$('#userlist').slideToggle(400);"><?=$clist['title']?><div style="font-size:65%;">在线会员:<b id="userzx" style="color:#ff0000;">loading...</b><b id="X">▽</b><b id="S" style="display:none;">△</b></div></div><div id="msts" class="right"><img class="ico_m" src="./bqimg/mess.gif">(<b id="mess" style="font-size:85%;color:#ff0000;">load...</b>)</div>

<div id="both" style="margin-bottom:4px;"></div>
<?if($a['zxlist']==1){?>
<div id="userlist" style="display:none;"><div class="userlist"><div style="width:1000%;" id="userlistb"><li style=""><img src="./tx/null.png"><div class="ustext">loading...</div></li></div></div>
<div class="l-r" style="position:absolute;left:0;top:52px;"><a onclick="tll()" style="float:right;">←</a></div><div class="l-r" style="position:absolute;top:52px;right:0;"><a onclick="hll()" style="float:right;">→</a></div>
</div>
<?}else{?>
<div id="userlist" style="display:none;"><div class="userlist" style="overflow-y:scroll;overflow-x:hidden;height:250px;"><div id="userlistb"><li style=""><img src="./tx/null.png"><div class="ustext">loading...</div></li></div></div>

</div>
<?}?>
<div id="both"></div>
<div id="ait" style="width:100%;line-height:33px;background:#dafbff;color:#00b3ff;font-size:90%;display:none;"></div>
<div id="both"></div>
<div id="bbs" style="position:absolute;left:-4000px;opacity:0.1;font-size:80%;display:none;overflow-y:scroll;max-height:200px;"></div>
<div id="both"></div>
</div>
<!--user-->
<div id="usermm" style="position:fixed;overflow-y:scroll;height:100%;top:0;left:0;right:0;max-width:600px;margin:0 auto;background:#fff;z-index:1000;display:none;">



</div>
<script>



var lu=false;
function hll(){
if(lu){
clearInterval(lu);
lu=false;
return false;
}
var u=0;
var left = $(".userlist").scrollLeft();
var wt = $(".userlist")[0].clientWidth;
lu=setInterval(function(){
u=u+2;
$(".userlist").scrollLeft(left+u);
if(u>wt){clearInterval(lu);lu=false;}
},5);
}
function tll(){
if(lu){
clearInterval(lu);
lu=false;
return false;
}
var left = $(".userlist").scrollLeft();
var wt = $(".userlist")[0].clientWidth;
var u=0;
lu=setInterval(function(){
u=u+2;
$(".userlist").scrollLeft(left-u);
if(u>wt){clearInterval(lu);lu=false;}
},5);
}
</script>

<div id="list" style="height:100%;-webkit-overflow-scrolling : touch;overflow-y:scroll;position:absolute;left:0;right:0;padding:0;margin:0 auto;" onclick="$('#userlist').hide();$('#cd').children().hide();" onscroll="gun()"><?=$ll?><div id="tip" style="position:absolute;top:0;left:0;right:0;text-align:center;"></div><div id="suo" style="position:absolute;display:none;right:3px;top:50px;text-align:center;font-size:30px;" onclick="js()"><img class="ico_m" src="./bqimg/1suo.png"></div></div>

<div class="bottom">

<form method="post" action="" enctype="multipart/form-data" id="J-add-form">
  <div class="ifu">
<li style="width:10%;float:left;"><input type="button" class="xxx" value="✕" onclick="$('#aname').text('');$('#sname').val('');$('#cfile').val('');$('#img').attr('src','');$('#textcon').html('');"></li>
<li style="width:70%;float:left;position:relative;"><div id="aname" style="height:42px;line-height:40px;"></div><div id="textcon" style="-moz-user-modify: read-write-plaintext-only;position:absolute;top:0;left:0;overflow-y:auto;-webkit-user-modify: read-write-plaintext-only;background-color:rgba(255,255,255,.8);" onclick="" onblur="wapd();"></div></li><textarea id="content" placeholder="输入内容" type="text" name="content" style="display:none"></textarea>
 <input type="file" name="file" id="cfile" accept="image/*" onchange="show(this);" style="display:none;">
<input type="hidden" id="dwid" name="dwid" value="">
<input type="hidden" id="sname" name="sname" value="">
<li style="width:20%;float:left;"><input type="button" id="Xx" value="发送" onclick="chatpost(this.id,this.value);"><?include'./php_html/majia.php';?></li></div>
</form>
<script>
saurl='<?=LL?>?h=zeng&mods=chat&chaid=<?=$id?>';
if(ua.indexOf('Window')!=-1){
document.onkeydown = function (e) {
            if (!e) e = window.event;
            if ((e.keyCode || e.which) == 13) {
if (!e.shiftKey){
e.cancelBubble=true;

e.preventDefault();

e.stopPropagation();
                chatpost('Xx','发送');}
            }
        }
}
if(ua.indexOf('WebKit')==-1){$("#textcon").attr('contenteditable','true');}
</script>
<div id="both"></div>
<?php 
include './php_html/global/form.php';
echo'</div>';
$niko=explode('|',$clist['img']);
if($niko[1]!=''){
echo'<script>$(document).ready(function(){$("html").css("background-image","url('.$niko[1].')");
});</script>';
}


include './php_html/global/bottom.php';
?>