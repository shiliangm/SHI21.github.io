<div id="ts" class="ts" style=""></div>
<div id="home" class="qjk" style="max-width:100%;overflow-y:scroll;display:block;" onclick="">
<div id="" class="juzon" style="width:100%;font-size:200%;text-align:center;font-weight:bold;color:#fff;">数据加载中,请稍等...</div></div>

<script>
//私信列表20wl.cn
var mehtml='';
var lefth='';
$("#msts").click(function(){
if($("#messlist").length>0){
$("#messlist").animate({width:'hide'},350);
setTimeout(function(){$("#messlist").remove();},350);
if(mehtml!=''){$("#msts").html(mehtml);
$(".left").html(lefth);
}
return false;
}
mehtml=$("#msts").html();
lefth=$(".left").html();
var bh=document.body.clientHeight;
var he=$(".header").outerHeight(true);
//var bo=$(".bottom").height();
$("#messlist").remove();
he=50;
$("body").append('<div id="messlist" style="position:fixed;overflow-y:scroll;height:'+(bh-he)+'px;top:'+(he)+';right:0;left:0;width:;max-width:'+$('body').css('max-width')+';margin:0 auto;background:#fff;z-index:1000;display:none;"><center>正在加载...</center></div>');
getwml('<?=LL?>?h=messlist','messlist','ms','');
$("#messlist").animate({width:'show'},350);
$("#msts").html('返回');
$(".left").html("<a onclick=\"getwml('<?=LL?>?h=messlist','messlist','ms','');ts('已刷新消息')\">刷新↺</a>");
});


function anlin(ulink){
if(dl==''){
ts('请先登录');
return false;
}
ju();
 //history.pushState(null,null,ulink);
   //$("body").html('');
 $("#fra").html('<div class="ts" id="frts" style="display:block;">正在加载中... <a onclick="$(\'#fra\').html(\'\');$(\'#youriframeid\').remove();xu();">取消</a></div><iframe id="youriframeid" style="background:#000;background-image:url(./php_html/css/bg.jpg);position:fixed;z-index:2500;left:0;right:0;top:0;bottom:0;margin:0px;padding:0;border:0;display:block;border:none; " src="'+ulink+'" width="100%" height="100%" frameborder="no" border="0" marginwidth="0" marginheight="0" scrolling="no" allowtransparency="yes"></iframe>');
 $("#fra").show();
 
//document.body.parentNode.style.overflow = "hidden";

}

function imgpo(urll,id){
ts('头像上传中...');
var formData = new FormData(document.getElementById(id));
    $.ajax({
          url:urll,
          type:'post',
          dataType:'text', 
          data:formData,
          cache: false,            
          processData: false,      
          contentType: false,      
          success:function(data){
          ts(data);
if(data.indexOf("请登录")!=-1){$("#logink").show();}
if(data.indexOf("成功")!=-1){
$("#wtx").attr('src','./tx/<?=$u['name']?>.png?_'+Date.parse(new Date()));
}
},
error:function(e){
ts('服务器繁忙,请重试！');
}
});
}


function by(id){return document.getElementById(id);}

function imu(ur){

by('ttt').style.display='flex';
by('tt2').src=ur.src;

}
function getwml(urr,id,bs,noid){
//url,内容显示,内容标识
if(noid!=''){
if($("#"+noid).is(':hidden')){}else{return false;}
}
$.get(urr,function(data,status){
if(status=='success'){
if(id!=''){
 $("#"+id).html(data.substring(data.indexOf('<!--'+bs)+6,data.indexOf(bs+'-->')));
}
}else{ts('请求出错,请重试');}
    });

}
function getts(urr,id){
//url,内容显示,内容标识
ts('请求中...');
$.get(urr,function(data,status){
if(status=='success'){
ts(data);
if(id!=''){

$('#'+id).fadeOut(1000);
}
}else{ts('请求出错,请重试');}
    });

}

function getxs(urr,id){
ts('请求中...')
$.get(urr,function(data,status){
if(status=='success'){
if(id!=''){
$('#'+id).fadeIn();
$('#'+id).html(data);
}
}else{ts('请求出错,请重试');}
    });
}

function user(ta){
$("#usermm").css('max-width',$('body').css('max-width'));

getxs('<?=LL?>?h=user&ta='+ta,'usermm');
}
</script>

		<script>		
		function fontys(str){
		if(by('xinput').value!=''){ts('您已设置气泡,文本颜色无法生效');}
		$('#fontys').css('color',str);
		$("#textcon").css("color",str);
		}
		function textz(str){
		var ser=by("textcon");
		ser.innerHTML=ser.innerHTML.replace(/<br>/g,'')+'<img src="'+str+'">';
		//.append('<img src="'+str+'">');
		
		}
		function so(id){
		if(!$('#'+id).is(":hidden")){$('#'+id).hide();return false;}
		$('#'+id).siblings().hide();
		$('#'+id).show();
		if(id=='b2'){document.getElementById('cfile').click();}
		}
			function show(file){	
		
				var reader = new FileReader();	// 实例化一个FileReader对象，用于读取文件
				var img = document.getElementById('img'); 	// 获取要显示图片的标签
				
				//读取File对象的数据
				reader.onload = function(evt){
			
					img.src = evt.target.result;
				
				}
			    reader.readAsDataURL(file.files[0]);
			}	
			
			document.addEventListener("paste", function (e) {

    let items = event.clipboardData && event.clipboardData.items;
    let file = null;
    if (items && items.length) {
        // 检索剪切板items中类型带有image的
        for (var i = 0; i < items.length; i++) {
            if (items[i].kind === 'file') { // 或者 items[i].type.indexOf('image') !== -1
                file = items[i].getAsFile(); // 此时file就是剪切板中的图片文件
jimg=file;
				xinn(file);
				$('#b2').siblings().hide();
		$('#b2').show();
                break;
            }
        }
    }
}, false);
function xinn(xx){

var reader = new FileReader();

reader.readAsDataURL(xx);

reader.onload = function (e) {
 
   $("#img").attr('src',e.target.result);
}
}
			
		</script>



<script>

  var dyc=1;
  
//if(dyc==1){ju();$("#suo").css("display","block");}
function gun(){
imgkj();
var top = $("#list").scrollTop();
//var bot = $("#list").scrollBottom();
var ght = $("#list")[0].scrollHeight;
var hght = $("#list")[0].clientHeight;


if(top<(ght-hght)){

$("#suo").css("top",top+hght-100+"px");
if(suo==1){
ju();
$("#suo").show();
//$("#content").val('已锁定');
}
}

if(top+10>(ght-hght)||top>(ght-hght)){
$("#suo").hide();
if(suo==2){
xu();

dyc=2;
//$("#content").val('已解锁');
}

}

　　
if(top<1&&rm==1){
//$("#tip").html('<br><br>正在加载...');
ts('正在加载...');
rm=2;
var url='<?=$url?>&t=gun&gun=<?=$gun?>&page='+(pg/1+1);
 $.ajax({
       url:url, 
       type:'get',        
       dataType:'text',    
       data:'',
           
       success:function(data){
  if(data==''){
//$("#tip").html('<br><br>没有记录了');
ts('没有更多记录了');
}else{
$("#list").prepend(data);}
       if(data!=''){pg=(pg/1+1);rm=1;$("#list").scrollTop(ksg);}
       }
     });
}

}



  $(document).ready(function(){



//刚进入页面的内容高度,用来查看记录定位
setTimeout(function(){
var bh=document.body.clientHeight;
var boy=document.body.scrollHeight;

var he=$(".header").outerHeight(true);
var bo=$(".bottom").outerHeight(true);
$("#list").css({"height":(bh-50-bo)+'px','top':'50px'});

xu();

ksg=$("#list")[0].scrollHeight;
document.body.scrollTop =boy;
if(window.location.href.indexOf('bbs')==-1){
dbb();
}
document.body.scrollTop =boy;
$("#home").fadeOut(200);
},1000);
});
$(window).resize(function() {
  $("#list").css({"height":(document.body.clientHeight-50-$(".bottom").outerHeight(true))+'px','top':'50px'});
});
</script>
<script>if(isIE()){
$(".bottom").css('margin','0px');
}
</script>
</body></html>