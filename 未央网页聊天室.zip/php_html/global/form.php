
<div class="bttn"><li><a onclick="so('b1');">&nbsp;<img src="./bqimg/bq.png" class="ico_m">&nbsp;</a></li><li><a onclick="so('b2');">&nbsp;<img class="ico_m" src="./bqimg/1img.png">&nbsp;</a></li><li><a onclick="so('b3')">&nbsp;<img class="ico_m" src="./bqimg/1T.png">&nbsp;</a></li><li><a id="fontys" onclick="so('b4')" style="font-size:130%;color:#000;">✐</a></li><li><a onclick="alert('游戏和礼物系统系统开发中,您可以使用金币来玩游戏或赠送礼物');so('b5')">&nbsp;<img class="ico_m" src="./bqimg/1liwu.png">&nbsp;</a></li></div>
<div id="both"></div>
<div class="cd" id="cd">
<li id="b1"><div class="bq" style="">
<?php
for($i=1;$i<=37;$i++){
echo'<span><img src="./bqimg/bq'.$i.'.png" onclick="textz(\'./bqimg/bq'.$i.'.png\')"></span>';
}
?>

</div></li>
<li id="b2"><img onclick="$(this).parent().hide();$('#cfile').val('');this.src='';" style="max-height:80px;border:5px #000 dashed;" id="img" src=""><br>支持电脑直接粘贴图片</li>
<li id="b3"><div class="bq" style="height:44px;"><span class="xc1" style="font-size:150%;width:100%;" onclick="if(by('xinput').value==''){by('xinput').value='1';by('xccc').innerHTML='✔️已选择';}else{by('xinput').value='';by('xccc').innerHTML='';}">炫彩字体气泡<b id="xccc"></b></span></div>
<input type="hidden" id="xinput" value="">
</li>
<li id="b4"><div class="bq" style="height:44px;">
<span style="font-size:200%;color:#00000;" onclick="fontys('#000000');">■</span><span style="font-size:200%;color:#ff3ed9;" onclick="fontys('#ff31d9');">■</span>
<span style="font-size:200%;color:#ffa928;" onclick="fontys('#ffa928');">■</span><span style="font-size:200%;color:#6d728d;" onclick="fontys('#6d728d');">■</span><span style="font-size:200%;color:#02a500;" onclick="fontys('#02a500');">■</span><span style="font-size:200%;color:#7c0521;" onclick="fontys('#7c0521');">■</span><span style="font-size:200%;color:#0000fd;" onclick="fontys('#0000fd');">■</span><span style="font-size:200%;color:#6e0cfd;" onclick="fontys('#6e0cfd');">■</span></div></li>
</div>
<?
/**if(!stristr($_SERVER['SERVER_NAME'],'yzsyzx.cn')){die(base64_decode('ZXJyb3IlMjBieSUyMGFubGluLWNoYXQlMjAlM0ElMjBjaGF0LjIwd2wuY24='));}**/
?>
