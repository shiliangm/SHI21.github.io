
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<meta name="renderer" content="webkit">
<meta http-equiv="Expires" content="0">
<meta http-equiv="Pragma" content="no-cache">
<meta http-equiv="Cache-control" content="no-cache">
<meta http-equiv="Cache" content="no-cache">
<title><?=$btooo?>_<?=$a['title']?> - by anlin-chat</title>
<meta data-react-helmet="true" name="keywords" content="<?=$a['title']?>"/>
<script type="text/javascript" src="https://apps.bdimg.com/libs/jquery/2.1.1/jquery.min.js"></script>
<style>
*{font-family: "Arial","Microsoft YaHei","黑体","宋体",sans-serif;}
.ico_m{width:25px;vertical-align:middle;}

</style>
<script>
var ua=navigator.userAgent;


var dl='<?=$u['name']?>';
function ts(nr){
$("#ts").css('display','block');
$("#ts").css('max-width',$('body').css('max-width'));
if(nr.indexOf('</head>')>-1){
$("#ts").html('未知错误,请关闭防火墙');
  $("#ts").fadeOut(2400);
return false;}
$("#ts").html(nr);
  $("#ts").fadeOut(2400);
//setTimeout(function(){$("#ts").css('display','none');},1500);
}

function aite(yhm,zh,dwtt){
$("#dwid").val(dwtt);
$("#aname").text('回复:'+yhm);
$("#sname").val(zh);
foc();
}
function foc(){
//ell.blur();
var textbox = document.getElementById('textcon');
var sel = window.getSelection();
var range = document.createRange();
range.selectNodeContents(textbox);
range.collapse(false);
sel.removeAllRanges();
sel.addRange(range);

}
var saurl='';
var jimg='';//粘贴板中的img
function chatpost(id,va){
//alert('网站调试中,无法回复'+saurl);return false;
var zcon=$("#textcon").html();
if($("#cfile").val()==''){
if(zcon==''||zcon=='<br>'){if(jimg==''){ts('请输入内容');return false;}}
}
var p="chatpost('"+id+"','"+va+"')";
$("#"+id).attr('onclick','');
$("#"+id).val(va+'中...');
setTimeout(function(){if($("#"+id).val()==va+'中...'){
ts('服务器繁忙,请重试');
$("#"+id).val(va);$("#"+id).attr('onclick',p);}},20000);

$('#cd').children().hide();
$("#list").append('<div class="linss"><div class="lined">刚刚</div><div class="linet" style="text-align:right;"><?=$u['user']?></div><div class="name ri"><img src="<?=$u['tx']?>"></div><div id="" class="line lin2 ri"><font style="color:rgb(0,0,0);">'+zcon+'</font></div></div><div id="both" style="margin-bottom:10px;"></div>');
dbb();
zcon=zcon.replace(/<img src="(.*?)"(.*?)>/g,"\[img\]$1\[\/img\]");
zcon=zcon.replace(/<img src='(.*?)'(.*?)>/g,"\[img\]$1\[\/img\]");

zcon=zcon.replace(/<img style="(.*?)" src="(.*?)">/g,"\[img\]$2\[\/img\]");
zcon=zcon.replace(/<br>/g,"\[br\]");
if(ua.indexOf('WebKit')==-1){
zcon=zcon.replace(/<div>/g,"");
zcon=zcon.replace(/<\/div>/g,"");
}

var xuan=$("#xinput").val();
if(xuan!=''){
zcon='[fontxc'+xuan+']'+zcon+'[/fontxc'+xuan+']';
}else{

zcon='[font=color:'+$("#textcon").css("color").replace(/ /g,'')+';]'+zcon;
zcon+='[/font]';

}
$("#content").val(zcon);
    var formData = new FormData(document.getElementById("J-add-form"));
if(jimg!=''){
formData.append("file",jimg);
}
    $.ajax({
          url:saurl,
          type:'post',
          dataType:'text', 
          data:formData,
          cache: false,            
          processData: false,      
          contentType: false,      
          success:function(data){
          ts(data);
if(data.indexOf("请登录")!=-1){$("#logink").show();}
if(data.indexOf("成功")!=-1){
js();
$("#content").val('');
$("#textcon").html('');
$("#cfile").val('');
$("#img").attr('src','');

$("#dwid").val('');
$('#aname').text('');$('#sname').val('');
jimg='';

}
$("#"+id).attr('onclick',p);
$("#"+id).val(va);

          },
          error:function(e){
              ts('服务器繁忙,请重试！');
$("#"+id).attr('onclick',p);
$("#"+id).val(va);
           }
    });



}


function wapd(){ if(document.body.scrollTop !=document.body.scrollHeight){document.body.scrollTop =document.body.scrollHeight;}


}

function dbb(){
var top = $("#list").scrollTop();

var ght = $("#list")[0].scrollHeight;
var hght = $("#list")[0].clientHeight;
var dok=document.getElementById('list');
if(top!=(ght-hght)){
dok.scrollTop=dok.scrollHeight;
}


}
var sx='';
var suo=2;
function xu(){
if(suo==2){
get(); 
sx=setInterval("get()",<?=$a['get']?>000);suo=1;
}}
function ju(){
aj.abort();
clearInterval(sx);
suo=2;aj.abort();}
var ksg='';
var pg='<?=($_GET['page']-1)?>';
var rm=1;
function js(){if($("#suo").css("display")=='block'){dbb();
$("#suo").css("display","none");}}

function listlo(thiss){

var imgg=thiss.offset().top-$('#list').offset().top;
if(imgg>0&&imgg<$('#list')[0].clientHeight){
thiss.siblings().remove();
thiss.css('visibility','visible');
thiss.removeClass('tutu');}

}

function imgkj(){ 
 $("#list").find("img.tutu").bind("myload",function(){listlo($(this));});
$("#list").find("img.tutu").trigger("myload");
}

