<div id="fra" style="display:none;margin:0;padding:0;background:#ff0000;"></div>

<div id="ttt" style="overflow-y:scroll;z-index:5000;background-color:rgba(0,0,0,.7);position:fixed;left:0; right:0; top:0; bottom:0;margin:0 auto;max-width:100%;width:100%;display:none;" onclick="by('ttt').style.display='none';"><center><img id="tt2" src="" class="juzon" style="max-width:100%;"  onclick="by('ttt').style.display='none';"></center></div>
<!--登录框-->
<div id="logink" class="qjk" style="overflow-y:scroll;display:none;z-index:2000;" onclick="">
<div id="lo" class="juzon" style="width:100%;">
<div class="linput"><button id="" type="button" style="background:#235eb2" class="lbtn" onclick="$('#logink').hide();xu();">关闭窗口</button></div><br>

<form id="logg" action="" method="post" onclick="ju();">
<center><div style="font-size:200%;color:#000;text-shadow:#FFF 2px 2px 3px;">登录账号</div></center><br>
<div class="linput papa"><input class="linputz" id="denglu" name="name" type="text" placeholder="请输入账号"></div><br>
<div class="linput papa"><input class="linputz" name="pass" type="password" placeholder="请输入密码"></div><br>
<div class="linput"><button id="loggbtn" type="button" class="lbtn" onclick="getpo(this,'<?=LL?>?h=zeng&mods=login','logg');">登录</button></div>
<br><div class="linput"><button id="loggbtn" type="button" class="lbtn" onclick="$('#logg').hide();$('#regg').show();$('#passcz').hide();" style="background:#00da00">注册账号</button></div>
<br><div class="linput"><button id="loggbtn" type="button" class="lbtn" onclick="$('#logg').hide();$('#passcz').show();" style="background:#980000">找回/重置密码</button></div>
</form>
<form id="passcz" action="" method="post" onclick="ju();" style="display:none;">
<center><div style="font-size:200%;color:#000;text-shadow:#FFF 2px 2px 3px;">重置密码</div></center><br>
<div class="linput papa"><input class="linputz" id="denglu" name="name" type="text" placeholder="请输入账号"></div><br>
<div class="linput papa"><input class="linputz" name="mail" type="email" placeholder="请输入你的邮箱"></div><br>
<div class="linput papa"><input class="linputz" name="xpass" type="password" placeholder="请输入新的密码"></div><br>
<div class="linput"><button style="background:#980000" id="czbtn" type="button" class="lbtn" onclick="getpo(this,'<?=LL?>?h=zeng&mods=passcz','passcz');">确认重置(接收激活邮件)</button></div>

<br><div class="linput"><button id="reggbb" type="button" class="lbtn" onclick="$('#logg').show();$('#passcz').hide();">返回登录</button></div>
</form>

<!--注册表单-->
<form id="regg" action="" method="post" style="display:none;" onclick="ju();">
<center><div style="font-size:200%;color:#000;text-shadow:#FFF 2px 2px 3px;">注册账号</div></center><br>
<div class="linput papa"><input class="linputz" id="zhuce" name="name" type="text" placeholder="请输入账号"></div><br>
<div class="linput papa"><input class="linputz" name="user" type="text" placeholder="请输入昵称"></div><br>
<div class="linput papa"><input class="linputz" name="pass" type="password" placeholder="请输入密码"></div><br>
<div class="linput papa"><input class="linputz" name="rpass" type="password" placeholder="请再次密码"></div><br>
<?if($a['zc']==1){echo'<div class="linput papa"><input type="text" class="linputz" name="code" value="" placeholder="邀请码(必填)"></div><br>';}?>

<?if($a['zc']==4&&$a['smtpserver']!=''){echo'<div class="linput papa"><input class="linputz" name="mail" placeholder="你的邮箱"></div><br>';}?>

<div class="linput"><button id="reggbtn" type="button" class="lbtn" onclick="getpo(this,'<?=LL?>?h=zeng&mods=reg','regg');" style="background:#00da00">确认注册</button></div>
<br><div class="linput"><button id="reggbb" type="button" class="lbtn" onclick="$('#logg').show();$('#regg').hide();">返回登录</button></div>
</form>
</div>
</div>
<script>
function getpo(thi,urlr,id) {
thi.disabled=true;
if(thi.id=='loggbtn'){   ts('正在登录,请稍后...');}else{ts('请求中,请稍后...');}
         $.ajax({
         type: "POST",
         dataType: "text",
         url: urlr ,
         data: $('#'+id).serialize(),
      success: function (data) {
ts(data);
thi.disabled=false;
if(data.indexOf('登录成功')!=-1){
$("#logink").hide();
$("#nologin").hide();
$("#yeslogin").show();
dl='Yes';
xu();
}
if(data.indexOf('注册成功')!=-1){
$('#logg').show();$('#regg').hide();
$("#denglu").val($("#zhuce").val());
}
},
 error : function() {
thi.disabled=false;
 alert("请求失败,请重试");
 }
});
}
$("input").click(function(){document.body.scrollTop =document.body.scrollHeight;});
$("input").blur(function(){document.body.scrollTop =document.body.scrollHeight;});
</script>
<!--登录框结束-->