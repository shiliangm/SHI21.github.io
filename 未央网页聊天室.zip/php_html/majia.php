 <?if($u['qx']=='5'||$u['qx']=='2'||$u['qx']=='1'){
if($u['t']==''){$u['t']=$u['name'];}
$maque=$my->query("SELECT name,user,qx,t FROM Anlin_user where qx='5' and t='".$u['t']."' or qx='5' and t='' order by time desc limit 100");

while($oo=$my->fetch($maque)){


$xx.='<a onclick="getts(\''.LL.'?h=zeng&mods=mj&name='.$oo['name'].'\',\'mj\');">'.$oo['user'].'</a> | ';

}
if($xx==''){$xx='暂无马甲账户,请至后台添加';}
echo'<div style="width:20px;position:absolute;right:0px;top:-3px;" type="button" onclick="$(\'#mj\').toggle();$(\'#mj\').css({\'left\':$(this).offset().left-350,\'top\':$(this).offset().top-300});">⚲</div>
<div id="mj" style="display:none;position:fixed;top:100px;left:0;right:0;max-width:300px;height:300px;overflow-y:scroll;margin:0 auto;padding:10px;line-height:25px;border:3px #ff0000 solid;border-radius:3px;background:#fff;color:#000;">
<button type="button" onclick="$(\'#mj\').toggle();" style="width:100%;">关闭</button>点击昵称可直接切换至该账户(归属:'.$u['t'].')<br>
'.$xx.'

</div>

';
}
?>