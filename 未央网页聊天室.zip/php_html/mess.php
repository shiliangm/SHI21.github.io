<?php 

/**安林网络私聊列表20wl.cn 
mess.php?name=
**/
include './Anlin_class/define.php';
include './Anlin_class/ubb.php';
include './config.php';
$time=time();
function kie($no,$no2){
global $time;
setcookie($no,$no2,$time+86400);}
$my=new mys;
//$id=htmlx($_GET['id']);
//if($id==''){$id=1;}//开发者测试时使用

$t=htmlx($_GET['t']);
//当前用户信息开始
$name=htmlx($_COOKIE['name']);

if($name!=''){
$u=$my->cha("Anlin_user","name='".$name."' and pass='".htmlx($_COOKIE['pass'])."'");
if($u['name']==''){exit(UTF8.'<br><br><br><br><br><br><br><br><br><br>您的登录信息已失效,请登录后再进行访问<a href="'.LL.'?h=chat">返回</a>');}
}

//当前消息数据开始
$sname=htmlx($_GET['sname']);

$taus=$my->fetch($my->query("SELECT name,user FROM Anlin_user where name='$sname'"));
$btooo='与'.$taus['user'].'对话';
if($taus['user']==''){exit('Error:User-->BuCunZai'.$_SERVER['REQUEST_URI']);}

$mess=$my->fetch($my->query("SELECT*FROM Anlin_chatmesslist WHERE sname='$name' and kname='$sname'"));
if($mess['id']==''){
$mess=$my->fetch($my->query("SELECT*FROM Anlin_chatmesslist WHERE sname='$sname' and kname='$name'"));
}

//exit($mess['id'].'666'.$name);
//!$mess['id']=='' or $mess['id']='';

//聊天列表数据开始

if(is_numeric($t)){
if($_COOKIE['t']==$t){exit();}

kie('t',$t);

$t=$_COOKIE['cf'];
if($t==''){$t=$time;}
}

$tt=" and time>".$t;
if($t=='@'){$tt='';}
if($t=='gun'){$tt=" and time<".htmlx($_GET['gun']);}
if($t==''){$tt='';}else{

}

$o=$my->chax("Anlin_chatmess",'where chaid=\''.$mess['id'].'\''.$tt.' order by time desc',$a['sl']);

//sql_ajax全能翻页开始
if($_GET['gun']!=''){
if(!$_GET['page']||$_GET['page']==''){$_GET['page']='0';}
if($_GET['page']>$my->ce-1&&$t==''){exit('{"error":"page"}');}
if($_GET['page']<0){exit('pagea');}
}
//for输出聊天数组
$co=count($o)-1;
for($i=$co;$i>=0;$i--){
if($i==$co){$gun=$o[$i]['time'];}
if($o[$i]['kname']==$name){
$float='ri';
$sty='style=\'text-align:right;\'';
$lin='lin2 ri';
}else{$float='le';
$sty='';
$lin='lin le';}
$tu5=$my->fetch($my->query("SELECT name,tx FROM Anlin_user WHERE name='".$o[$i]['kname']."' limit 1"));
if($u['qx']=='1'){$sscc='<b onclick="getts(\''.LL.'?h=admin&mods=messxx&id='.$o[$i]['id'].'\',\'id'.$o[$i]['id'].'\')">删</b>';}else{$sscc='';}
$tu5=$tu5['tx'];
if($tu5==''){$tu5='./tx/null.png';}
$ll.='<div id="id'.$o[$i]['id'].'"><div data="'.$o[$i]['id'].'" class="lined" id="d'.$o[$i]['time'].'">'.date("Y-m-d H:i:s",$o[$i]['time']).'</div><div class="linet" '.$sty.'>'.$sscc.'<a onclick="user(\''.$o[$i]['kname'].'\');">'.$o[$i]['kuser'].'</a></div><div class="name '.$float.'"><img src="'.$tu5.'" onclick="user(\''.$o[$i]['kname'].'\');"></div><div class="line '.$lin.'">'.ubb($o[$i]['content']).'</div></div><div id="both" style="margin-bottom:10px;"></div>';
if($i==$co){
$idx=$o[$i]['id'];}
}

//for数组结束
if($_GET['gun']==''){//gun
if($ll!=''){
kie('cf',$time);
if($t!=''){//t
//if($_COOKIE['idx']==$idx&&$_COOKIE['idx']!=''){exit;}kie('idx',$idx);
}//t
}

$ll.='<!--id'.$idx.'id-->';
$ll.='<!--zs'.$my->zs.'zs-->';
//消息数量
if($name!=''){

$my->gai("Anlin_chatmess","y='1' WHERE kname='$sname' and sname='$name'");
$mesl=$my->rowk("Anlin_chatmess WHERE y!='1' and sname='$name'");
$ll.='<!--ms'.$mesl.'ms-->';
}else{$ll.='<!--ms0ms-->';}
//消息数量
}//gun
if($t!=''){

exit($ll);
}
$wbb=$_GET['wbb'];
$url=LL.'?'.$_SERVER['QUERY_STRING'];
echo'<html><head>';
echo UTF8;
include './php_html/global/head.php';
?>


var aj=null;
var tyz='<?=$time?>';
var xid='';//请求成功时获取一段该数据唯一标识的id,尽管ajax会产生各种停顿和延迟并发卡顿等bug 都将不再重复获取数据
function get(){

var url='<?=$url?>&t='+tyz;
aj=$.ajax({
       url:url, 
       type:'get',        
       dataType:'text',    
       data:'',
       //async:false,
       success:function(data){

var time = Date.parse(new Date());
time=(time/1000);
tyz=time;
if(data!=''){
var msshu=data.indexOf('ms-->');
if(msshu==-1){return false;}
var datass=data.replace(/<!--(.*?)-->/g,'');
var mess=data.substring(data.indexOf('<!--ms')+6,msshu);
if(mess/1>0){
$('#mstsxxx').attr('class','right blink');
$('#msts').attr('class','right blink');
}else{
$('#mstsxxx').attr('class','right');
$('#msts').attr('class','right');
}
$("#mess").text(mess);
if(datass!=''){
var sxid=data.substring(data.indexOf('<!--id')+6,data.indexOf('id-->'));

if(xid!=sxid){
//此时userzx是会员消息数量
$('#userzx').text($('#userzx').text()/1+(data.substring(data.indexOf('<!--zs')+6,data.indexOf('zs-->')))/1);
$("#list").append(datass);
xid=sxid;
$(".linss").remove();
}



}

}
     

       dbb();}
     });


}

<?if($wbb==''){?>
parent.tshide();<?}else{?>
function closeIFrame(){
        $("iframe").attr("src","javascript:false");
        $('#youriframeid').remove();
xu();

getwml('<?=LL?>?h=messlist','messlist','ms','');
    }
function tshide(){
        
        $('#frts').hide();

    }
<?}?>
</script>
</head><body>

<?php if(ua()){include './php_html/global/load.html';}else{include './php_html/global/loadpc.html';}

include './php_html/global/login.php';
?>
<div id="usermm" style="position:fixed;overflow-y:scroll;height:100%;top:0;left:0;right:0;max-width:600px;margin:0 auto;background:#fff;z-index:1000;display:none;">



</div>
<div class="header" style=""><div class="left"><a style="" id="loginxx" onclick="<?if($wbb!=''){?>history.back();<?}else{?>ju();parent.closeIFrame();<?}?>">⬅︎</a>
</div>
<div class="center">与<?=$taus['user']?>的会话<div style="font-size:65%;">共<b id="userzx" style="color:#ff0000;"><?=$my->zs;?></b>条聊天记录</div></div>
<div id="msts<?if($wbb==''){?>xxx<?}?>" class="right" onclick="<?if($wbb==''){?>ju();$('#msts',parent.document).trigger('click');parent.closeIFrame();<?}?>"><img class="ico_m" src="./bqimg/mess.gif">(<b id="mess" style="font-size:80%">0</b>)</div>
<div id="both" style="margin-bottom:4px;"></div>

<div id="ait" style="width:100%;line-height:33px;background:#dafbff;color:#00b3ff;font-size:90%;display:none;"></div>

<div id="both"></div>
</div>
<div id="list" style="height:100%;-webkit-overflow-scrolling : touch;overflow-y:scroll;position:absolute;left:0;right:0;padding:0;margin:0 auto;" onclick="$('#cd').children().hide();" onscroll="gun()"><?=$ll?><div id="tip" style="position:absolute;top:0;left:0;right:0;text-align:center;"></div><div id="suo" style="position:absolute;display:none;right:3px;top:50px;text-align:center;font-size:30px;" onclick="js()"><img class="ico_m" src="./bqimg/1suo.png"></div></div>
<div class="bottom">
<form method="post" action="" enctype="multipart/form-data" id="J-add-form">
  <div class="ifu">
<li style="width:10%;float:left;"><input type="button" class="xxx" value="✕" onclick="$('#textcon').html('');$('#cfile').val('');$('#img').attr('src','');"></li>
<li style="width:70%;float:left;position:relative;"><div id="aname" style="height:42px;line-height:40px;">输入信息</div><div id="textcon" style="-moz-user-modify: read-write-plaintext-only;-webkit-user-modify: read-write-plaintext-only;position:absolute;top:0;left:0;overflow-y:auto;background-color:rgba(255,255,255,.8);" onclick="$('#aname').html('');" onblur="wapd();"></div></li><textarea id="content" placeholder="输入内容" type="text" name="content" style="display:none"></textarea>
 <input type="file" name="file" id="cfile" accept="image/*" onchange="show(this);" style="display:none;">
<input type="hidden" id="dwid" name="dwid" value="">
<input type="hidden" id="sname" name="sname" value="<?=$sname?>">
<li style="width:20%;float:left;"><input type="button" id="Xx" value="发送" onclick="chatpost(this.id,this.value);"></li></div>
</form>
<script>
saurl='<?=LL?>?h=zeng&mods=chat&chaid=<?=$mess['id']?>&ac=mess&sname=<?=$sname?>';
if('<?=$my->zs;?>'=='0'){$('#aname').html('打个招呼吧,这是你们第一条信息');}
foc();


if(ua.indexOf('Window')!=-1){
document.onkeydown = function (e) {
            if (!e) e = window.event;
            if ((e.keyCode || e.which) == 13) {
if (!e.shiftKey){
e.cancelBubble=true;

e.preventDefault();

e.stopPropagation();
                chatpost('Xx','发送');}
            }
        }
}
if(ua.indexOf('WebKit')==-1){$("#textcon").attr('contenteditable','true');}
</script>
<div id="both"></div>
<?php 
include './php_html/global/form.php';
echo'</div>';
if($taus['name']==''){echo'<script>alert("用户不存在");ju();parent.closeIFrame();</script>';}
include './php_html/global/bottom.php';

?>