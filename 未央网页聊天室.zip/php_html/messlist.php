<?php 

/**安林网络聊天室列表20wl.cn 
chat.php?id=聊天室id
**/
include './Anlin_class/define.php';
include './Anlin_class/ubb.php';
include './config.php';
$time=time();
$name=$_COOKIE['name'];
$my=new mys;
if($name!=''){
$u=$my->cha("Anlin_user","name='".$name."' and pass='".htmlx($_COOKIE['pass'])."'");
}
if($u['name']==''){exit('<!--ms<center>请先登录账号</center><script>$(\'#msts\').trigger("click");$("#logink").show();</script>ms-->');}
//$id=htmlx($_GET['id']);
$o=$my->chax("Anlin_chatmesslist","where kname='$name' or sname='$name' order by time desc",30);
//sql_ajax全能翻页开始
if(!$_GET['page']||$_GET['page']==''){$_GET['page']='0';}
if($_GET['page']>$my->ce-1&&$t==''){exit('<!--ms<center>暂无聊天消息</center>ms-->');}
if($_GET['page']<0){exit('pagea');}
//for输出聊天数组
$co=count($o)-1;
$edzs=0;
for($i=0;$i<=$co;$i++){
if($o[$i]['kname']==$name){
$df= $o[$i]['sname'];
}else{
$df= $o[$i]['kname'];
}
$tx=$my->fetch($my->query("SELECT name,user,tx FROM Anlin_user WHERE name='$df'"));
$txx=$tx['tx'];
if($txx==''){$txx='./tx/null.png';}

$dfname=$tx['user'];
$wdsl=$my->rowk("Anlin_chatmess WHERE y!='1' and kname='$df' and sname='$name'");
if($wdsl=='0'){$yc='display:none;';}else{$yc='display:block;';}
$ll.='<div class="mlist" onclick="anlin(\''.LL.'?h=mess&sname='.$df.'\')"><img src="'.$txx.'" class="mlistimg"><div class="mlistname">'.$dfname.'</div><div class="mlistdate">'.date("Y-m-d H:i",$o[$i]['time']).'</div><div class="mlcon">'.str_replace('<br>',' ',ubb($o[$i]['y'])).'</div><div class="mlxx" style="'.$yc.'">'.$wdsl.'</div></div>';
$edzs=$edzs+$wdsl;
}
//for数组结束
echo'<!--ms<div class="wotitle">我的消息 ('.$edzs.'条未读)</div>'.$ll.'ms-->';




?>