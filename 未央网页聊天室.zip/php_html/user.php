<?php 
/**安林网络会员中心
**/
include './Anlin_class/define.php';
include './Anlin_class/ubb.php';
include './config.php';
$time=time();
$name=htmlx($_COOKIE['name']);
function qo($aa){
if($aa=='0'){$e='已被锁定';}
if($aa=='1'){$e='超级管理员';}
if($aa=='2'){$e='管理员';}
if($aa=='3'){$e='普通用户';}
if($aa=='4'){$e='已被禁言';}
if($aa=='5'){$e='马甲账户';}
return $e;
}
if($name!=''){
$my=new mys;
$ta=htmlx($_GET['ta']);
if($ta==''){
$mailfo='';
$u=$my->cha("Anlin_user","name='".$name."' and pass='".htmlx($_COOKIE['pass'])."'");
if($my->rowk("Anlin_userset where kname='".$u['name']."'")<1){
$mailfo='
<script>
function dimail()
  {
  var mailxx=prompt("请输您的邮箱","");
  
  if (mailxx!=null && mailxx!="")
    {
setTimeout(function(){
    var que=prompt("请再次输入您的邮箱","");
    if (que!=null && que!="")
    {
    if(mailxx!=que){alert("两次邮箱输入不一致");}else{getts("'.LL.'?h=zeng&mods=mailbd&mail="+mailxx+"&rmail="+que);}
    }
},1000);
    }
  }
</script>
<div id="muuv" class="uszz" onclick="dimail();"><a style="float:left;color:#ff0000;">请点此设置邮箱保护你的账号安全</a><span style="float:right;">➡︎</span></div>
<div id="both"></div>
';
}

}else{
$u=$my->cha("Anlin_user","name='".$ta."'");}
}
$wot='';
if($name==$u['name']){$wot='我';}else{$wot='它';}
?>
<div class="usert">
<div style="line-height:35px;float:left;margin-left:20px;width:50%;text-align:left;" onclick="$('#usermm').fadeOut();">⬅︎关闭</div><?if($name==$u['name']&&$name!=''){?><div style="line-height:35px;float:right;margin-right:20px;width:30%;text-align:right;" onclick="window.location.href='<?=LL?>?h=zeng&mods=exit';">退出账号</div><?}else{?> <div style="line-height:35px;float:right;margin-right:20px;width:30%;text-align:right;" onclick="window.location.href='<?=LL?>?h=mess&sname=<?=$u['name']?>&wbb=5';">私信TA</div> <?}?>
<div id="both"></div>
<?php 
if($name==''){exit('<center>请登录才能查看该会员资料</center></div></div>');}
if($u['name']==''){exit('<center>该用户不存在</center></div></div>');}
if($u['tx']==''){$u['tx']='./tx/null.png';}
?>

<div style="line-height:25px;padding:0 20px 20px 20px;">
 <form method="post" action="" enctype="multipart/form-data" id="txform"><input type="file" name="file" id="kaka" accept="image/*" onchange="imgpo('<?=LL?>?h=zeng&mods=xgtx','txform')" style="display:none;"></form><a href="javascript:void(0)" onclick="<?if($name==$u['name']){?>document.getElementById('kaka').click();<?}?>"><img id="wtx" src="<?=$u['tx']?>" style="border-radius:50%;width:90px;float:left;vertical-align:middle;"<?if($name!=$u['name']){echo' onclick="imu(this);"';}?>></a> <div style="float:left;margin-left:5px;font-size:80%;vertical-align:middle;"><li style=""><?if($wot=='我'){?>用户名 : <?=$u['name']?><?}?></li><li>昵称 : <?=$u['user']?> <?=qo($u['qx'])?>

<?
if($u['qx']=='1'){echo'<a href="'.LL.'?h=admin" style="color:#0000ff;">超级管理员后台</a>';}?>

</li><li>金币 : <?=$u['jb']?></li>
<li>注册时间 : <?=date("Y-m-d H:i:s",$u['time'])?></li>
</div>
<div id="both"></div>
</div>
</div>
<?if($wot=='我'){echo$mailfo;?>

<div class="uszz" onclick="$('#usermm').fadeOut();$('#msts').trigger('click')"><a style="float:left;">我的消息(<b id="mas">0</b>)</a><span style="float:right;">➡︎</span></div>
<div id="both"></div><?}?>
<div class="uszz" onclick="ts('暂无记录')"><a style="float:left;"><?=$wot?>收到的礼物</a><span style="float:right;">➡︎</span></div>
<div id="both"></div>
<div class="uszz" onclick="ts('暂无记录');"><a style="float:left;"><?=$wot?>回复的帖子</a><span style="float:right;">➡︎</span></div>
<div id="both"></div>