<?php 
include './Anlin_class/define.php';
include './if.php';
include './Anlin_class/ubb.php';
include './config.php';
function emojix($str){
  $regex = '/(\\\u[ed][0-9a-f]{3})/i';  
    $str = json_encode($str);  
    $str = preg_replace($regex, '', $str);
    return json_decode($str); }
$my=new mys;
$time=time();

function kie($no,$no2){
global $time;
setcookie($no,$no2,$time+3600);}
$mods=$_GET['mods'];

if($mods=='exit'){
setcookie("name",'',-$time);
setcookie("pass",'',-$time);
exit(UTF8.'<script>alert("退出成功");window.location.href="'.$_SERVER['HTTP_REFERER'].'";</script>');
}


if($_COOKIE['name']!=''){
$u=$my->cha("Anlin_user","name='".htmlx($_COOKIE['name'])."' and pass='".htmlx($_COOKIE['pass'])."'");
if($u['name']==''){exit('nologin');}

if($u['qx']<'1'){exit('该账户已被锁定,请等待管理员审核');}
}


function ubbyz($str){
global $u;
//ubb验证
if(strstr($str,'[/size]')||strstr($str,'[/url]')){
if($u['qx']>2){exit('没有权限');}
}
}
function adminlok($aid){
global $u,$my;

if($u['qx']=='2'){

$fok=$my->fetch($my->query("SELECT kname,n FROM Anlin_admin where kname='".$u['name']."'"));

if($fok['n']!=''){
$ex=explode(',',$fok['n']);
if(!in_array($aid, $ex)){exit('你没有权限操作该板块');}
}
}
}

if($mods=='yidu'){
login();
$yy=htmlx($_GET['yy']);
$uname=$u['name'];
$id=htmlx($_GET[id]);
$my->gai("Anlin_chat","y='0' WHERE y='$yy' and sname='$uname' and id='$id'");
exit('已读');
}
//新建用户
if($mods=='reg'){

if($_COOKIE['y']==''){
//exit('注册失败,请返回注册页面刷新,重新提交注册');
}else{
if($_COOKIE['y']>$time){
exit('您已注册,请不要重复提交');
}
}
if($a['zc']=='2'){exit('暂时关闭注册');}
if($a['zc']=='0'){$qx=0;}
if($a['zc']=='3'){$qx=3;}
if($a['zc']=='1'){
//邀请码注册
$code=$_POST['code'];
$du=@file_get_contents('./txts/#zc.txt');
//{ABC|3}
if(!strstr($du,'{'.$code.'|')){exit('邀请码不存在');}
preg_match("/\{".$code."\|(.*?)\}/s",$du,$z);
if($z[1]<1){exit('该邀请码无效');}
$du=preg_replace("/\{".$code."\|(.*?)\}/s",'{'.$code.'|'.($z[1]-1).'}',$du);

$qx=3;

}

$name=htmlx($_POST['name']);
$user=htmlx($_POST['user']);
$user=emojix($user);
$pass=$_POST['pass'];
if(ifs($name,'sss','15#3')){exit('账号长度限制3至15位');}
if(ifs($name,'zdy','0-9a-zA-Z_#!,@\*\-\.')!=true){exit('账号包含非法字符');}
if(ifs($pass,'sss','30#6')){exit('密码长度限制6至30位');}
if(ifs($user,'sss','7#2')){exit('昵称长度限制2-7位');}
$pass=md5($_POST[pass]);
if($pass!=md5($_POST['rpass'])){exit('两次密码输入不一致');}

!$my->rowk("Anlin_user WHERE name='$name'") or exit('账号已存在');
!$my->rowk("Anlin_user WHERE user='$user'") or exit('昵称已存在');
//邮件注册
if($a['zc']=='4'){
function isHTTPS()
{
    if (defined('HTTPS') && HTTPS) return true;
    if (!isset($_SERVER)) return FALSE;
    if (!isset($_SERVER['HTTPS'])) return FALSE;
    if ($_SERVER['HTTPS'] === 1) {  //Apache
        return TRUE;
    } elseif ($_SERVER['HTTPS'] === 'on') { //IIS
        return TRUE;
    } elseif ($_SERVER['SERVER_PORT'] == 443) { //其他
        return TRUE;
    }
    return FALSE;
}
$url = (isHTTPS() ? 'https://' : 'http://').$_SERVER['HTTP_HOST'].LL;

$mail=htmlx($_POST['mail']);
if(!ifs($mail,'email')||$mail==''){exit('邮件格式错误');}
$ro=$my->rowk("Anlin_userset where kname='$name' and mail='$mail' and qx='0'");
$mro=$my->rowk("Anlin_userset where mail='$mail'");
if($mro>0&&$ro<1){exit('该邮件已被注册,请更换');}

include './Anlin_class/smtps.php';
 $smtpserver = $a['smtpserver'];
//SMTP服 务器
 $smtpserverport = $a['smtpdk'];//SMTP服务器端口 
$smtpusermail = $a['smtpmail'];
//SMTP服务器的用户邮箱
 $smtpemailto = $mail;
//发送给谁 
$smtpuser = $a['smtpuser'];
//SMTP服务器的 用户帐号
 $smtppass = $a['smtppass'];
//SMTP服务器的 用户密码 
$mailsubject = "〖".$a['title']."〗注册激活邮件-请确认";
//邮件主题
$md5=md5($name.$time.rand(0,100));
$ccoo=$a['smtptip'];
$ccoo=str_replace('[mail]',$mail,$ccoo);
$ccoo=str_replace('[title]',$a['title'],$ccoo);
$ccoo=str_replace('[url]',"<a href='$url?h=zeng&mods=mail&id=".$md5."'>$url?h=zeng&mods=mail&id=".$md5."</a>",$ccoo);
$ccoo=str_replace('[name]',$name,$ccoo);
$ccoo=str_replace('[user]',$user,$ccoo);
 $mailbody = "<meta charset=\"utf-8\">
".$ccoo;
//邮件内容
 $mailtype = "HTML";
//邮件格式（HTML/TXT）,TXT为文本邮件 ########################################## 
$smtp = new smtp($smtpserver,$smtpserverport,true,$smtpuser,$smtppass);//这里面的一个true是表示使用身份验证,否则 不使用身份验证. 
$smtp->debug = NULL;//是否显示发送的调 试信息
 $smtp->sendmail($smtpemailto, $smtpusermail, $mailsubject, $mailbody, $mailtype);
if($mro=='0'&&$ro<1){
$my->zeng('Anlin_userset',"NULL,'$name','$user','$pass','','0','$md5','$mail','$time'");
}else{//否则修改
$my->gai("Anlin_userset","md5='$md5' where mail='$mail'");
     }
 exit('系统给你'.$mail.'发送了一封邮件,请在24小时内点击邮件中的链接完成激活,如果没收到邮件请检查垃圾箱或尝试更换邮箱或重新提交发送邮件<script>alert("系统给你'.$mail.'发送了一封邮件,请在24小时内点击邮件中的链接完成激活,如果没收到邮件请检查垃圾箱或尝试更换邮箱或重新提交发送邮件");</script>');
//exit
}
//邮件注册结束
if($my->zeng('Anlin_user',"NULL,'$name','$pass','$user','$qx','0','./tx/null.png','$time',''")){
if($a['zc']=='1'){
file_put_contents('./txts/#zc.txt',$du);
}
kie('y',$time+500);
exit('注册成功');}
}
//邮件激活
if($mods=='mail'){
$mid=htmlx($_GET['id']);
if($_SESSION['cos']==''){
$_SESSION['cos']=5;
exit('<html>Loading...
<script>
window.location.reload();
</script>
</html>');
}
$j=$my->cha("Anlin_userset","md5='$mid'");
if($j['qx']!='0'){message('该链接已失效或已激活');}
!$my->rowk("Anlin_user WHERE name='".$j['kname']."'") or message('激活失败,原因:账号已被注册,请更换账号重新注册');
!$my->rowk("Anlin_user WHERE user='".$j['kuser']."'") or message('昵称已存在');

if($my->zeng('Anlin_user',"NULL,'".$j['kname']."','".$j['kpass']."','".$j['kuser']."','3','0','./tx/null.png','$time',''")){
if($my->gai("Anlin_userset","qx='1' where md5='$mid'")){message('您的账号已激活成功',LL);}
}
message('账户激活失败,可能是服务器繁忙请稍后再试',LL);
}
//密码重置
if($mods=='mailcz'){
$mid=htmlx($_GET['id']);
if($_SESSION['cos']==''){
$_SESSION['cos']=5;
exit('<html>Loading...
<script>
window.location.reload();
</script>
</html>');
}
$j=$my->cha("Anlin_userset","md5='$mid'");
if($j['qx']!='5'){message('该链接已失效或已重置成功');}

if($my->gai("Anlin_userset","qx='1' where md5='$mid'")){
$my->gai("Anlin_user","pass='".$j['kpass']."' where name='".$j['kname']."'");
message('您的账号密码已重置成功,请使用新的密码登录',LL);}

message('系统错误,可能是服务器繁忙请稍后再试',LL);
}
if($mods=='passcz'){
function isHTTPS()
{
    if (defined('HTTPS') && HTTPS) return true;
    if (!isset($_SERVER)) return FALSE;
    if (!isset($_SERVER['HTTPS'])) return FALSE;
    if ($_SERVER['HTTPS'] === 1) {  //Apache
        return TRUE;
    } elseif ($_SERVER['HTTPS'] === 'on') { //IIS
        return TRUE;
    } elseif ($_SERVER['SERVER_PORT'] == 443) { //其他
        return TRUE;
    }
    return FALSE;
}
$url = (isHTTPS() ? 'https://' : 'http://').$_SERVER['HTTP_HOST'].LL;
$name=htmlx($_POST['name']);
$mail=htmlx($_POST['mail']);
$xpass=md5($_POST['xpass']);
if(!ifs($mail,'email')||$mail==''){exit('邮件格式错误');}
$ro=$my->rowk("Anlin_userset where kname='$name' and mail='$mail' and qx='1'");

if($ro<1){exit('该账号和邮件不一致,或该账号未绑定邮箱或未激活');}

include './Anlin_class/smtps.php';
 $smtpserver = $a['smtpserver'];
//SMTP服 务器
 $smtpserverport = $a['smtpdk'];//SMTP服务器端口 
$smtpusermail = $a['smtpmail'];
//SMTP服务器的用户邮箱
 $smtpemailto = $mail;
//发送给谁 
$smtpuser = $a['smtpuser'];
//SMTP服务器的 用户帐号
 $smtppass = $a['smtppass'];
//SMTP服务器的 用户密码 
$mailsubject = "〖".$a['title']."〗密码重置邮件-请确认";
//邮件主题
$md5=md5($name.$time.rand(0,100));

$ccoo="你的账号 $name 正在请求重置账号密码,请确认以下链接完成重置<br><a href='$url?h=zeng&mods=mailcz&id=".$md5."'>$url?h=zeng&mods=mailcz&id=".$md5."</a>";

 $mailbody = "<meta charset=\"utf-8\">
".$ccoo;
//邮件内容
 $mailtype = "HTML";
//邮件格式（HTML/TXT）,TXT为文本邮件 ########################################## 
$smtp = new smtp($smtpserver,$smtpserverport,true,$smtpuser,$smtppass);//这里面的一个true是表示使用身份验证,否则 不使用身份验证. 
$smtp->debug = NULL;//是否显示发送的调 试信息
 $smtp->sendmail($smtpemailto, $smtpusermail, $mailsubject, $mailbody, $mailtype);

$my->gai("Anlin_userset","kpass='$xpass',qx='5',md5='$md5' where mail='$mail'");
  
 exit('系统给你'.$mail.'发送了一封邮件,请在24小时内点击邮件中的链接完成密码重置,如果没收到邮件请检查垃圾箱或尝试重新提交发送邮件<script>alert("系统给你'.$mail.'发送了一封邮件,请在24小时内点击邮件中的链接完成密码重置,如果没收到邮件请检查垃圾箱或尝试重新提交发送邮件");</script>');

}
//密码重置
//提示未绑定邮箱的用户绑定
if($mods=='mailbd'){
login();
if($my->rowk("Anlin_userset where kname='".$u['name']."'")!=0){exit('您的账户已绑定邮箱');}
$mail=htmlx($_GET['mail']);
$rmail=htmlx($_GET['rmail']);
if(!ifs($mail,'email')||$mail==''){exit('邮件格式错误');}
if($my->rowk("Anlin_userset where mail='".$mail."'")!=0){exit('该邮箱已存在,请更换');}

if($mail!=$rmail){exit('两次邮件输入不一致');}
$my->zeng('Anlin_userset',"NULL,'".$u['name']."','".$u['user']."','".$u['pass']."','','0','','$mail','$time'");
exit('邮箱设置成功,你可以通过登录页面重置或找回密码<script>alert("邮箱设置成功,你可以通过登录页面重置或找回密码");</script>');
}
//提示
//用户登录
if($mods=='login'){
$name=htmlx($_POST['name']);
$pass=md5($_POST['pass']);
$my->rowk("Anlin_user WHERE name='".$name."' and pass='$pass'")>0 or exit('账号或密码有误');
setcookie("name",$name,$time+(86400*30));
setcookie("pass",$pass,$time+(86400*30));
exit('登录成功');
}

//马甲账户之间切换
if($mods=='mj'){
if($u['qx']!='5'&&$u['qx']!='2'){exit('没有权限');}
$nb=$my->fetch($my->query("SELECT name,pass FROM Anlin_user WHERE name='".htmlx($_GET['name'])."' and qx='5'"));
if($nb['name']==''){exit('马甲账号不存在');}
setcookie("name",$nb['name'],$time+(86400*30));
setcookie("pass",$nb['pass'],$time+(86400*30));

exit('切换成功');
}
/**管理员操作项**/
//删除单条消息
if($mods=='chatde'){
login();
$id=htmlx($_GET[id]);
if($u['qx']=='2'||$u['qx']=='1'){


$chas=$my->fetch($my->query("SELECT id,kname,chaid FROM Anlin_chat WHERE id='$id'"));
$dma=$my->fetch($my->query("SELECT name,qx FROM Anlin_user WHERE name='".$chas['kname']."'"));
if($dma['name']!=$u['name']){
if($dma['qx']=='1'||$dma['qx']=='2'){exit('不能删除相同级别会员的消息');}
}
adminlok($chas['chaid']);
$str=$my->fetch($my->query("SELECT id,content FROM Anlin_chat where id='$id'"));
$str=$str['content'];
$str=preg_replace_callback("/\[img=(.+?)\]\.\/imgcache\/(.*?)\[\/img\]/is", bz( '$m', 'unlink("./imgcache/".$m[2]);' ), $str);
$my->shan('Anlin_chat',"id='$id'");
exit('删除成功');
}else{exit('没有权限');}
}

//删除论坛回复
if($mods=='chatbbsde'){
login();
$id=htmlx($_GET[id]);
if($u['qx']=='2'||$u['qx']=='1'){
$chas=$my->fetch($my->query("SELECT id,kname,content,bbsid FROM Anlin_chatbbshui WHERE id='$id'"));
$dma=$my->fetch($my->query("SELECT name,qx FROM Anlin_user WHERE name='".$chas['kname']."'"));
if($dma['name']!=$u['name']){
if($dma['qx']=='1'||$dma['qx']=='2'){exit('不能删除相同级别会员的消息');}
}
$bb=$my->fetch($my->query("SELECT id,chaid FROM Anlin_chatbbs where id='".$chas['bbsid']."'"));
adminlok($bb['chaid']);

$str=$chas['content'];
$str=preg_replace_callback("/\[img=(.+?)\]\.\/imgcache\/(.*?)\[\/img\]/is", bz( '$m', 'unlink("./imgcache/".$m[2]);' ), $str);
$my->shan('Anlin_chatbbshui',"id='$id'");
exit('删除成功');
}else{exit('没有权限');}
}

//
//禁言 解禁
if($mods=='jy'){
login();
if($u['qx']!='2'){if($u['qx']!='1'){exit('没有权限');}}
$s=$my->fetch($my->query("SELECT name,qx FROM Anlin_user WHERE name='".htmlx($_GET['name'])."'"));
if($s['name']==''){exit('用户不存在');}
//管理权限分类
if($u['qx']=='2'){
$for=$my->fetch($my->query("SELECT kname,n FROM Anlin_admin where kname='".$u['name']."'"));
if($for['n']!=''){
$ex=explode(',',$for['n']);
$cc=0;
foreach($ex as $value){
  $cc=$cc+$my->rowk("Anlin_chat where chaid='$value' and kname='".$s['name']."'");
 }
if($cc=='0'){exit('该用户未在你管理的板块发言过,你不能操作它');}
}
}
//
if($s['qx']=='3'){
$my->gai("Anlin_user","qx='4' WHERE name='".htmlx($_GET['name'])."'");
exit('已禁言,再次点击可解禁');
}
if($s['qx']=='4'){
$my->gai("Anlin_user","qx='3' WHERE name='".htmlx($_GET['name'])."'");
exit('已解除禁言');
}
exit('您不能禁言该用户');
}
//锁定 解锁
if($mods=='suo'){
login();
if($u['qx']!='2'){if($u['qx']!='1'){exit('没有权限');}}
$s=$my->fetch($my->query("SELECT name,qx FROM Anlin_user WHERE name='".htmlx($_GET['name'])."'"));
//管理权限分类
if($u['qx']=='2'){
$for=$my->fetch($my->query("SELECT kname,n FROM Anlin_admin where kname='".$u['name']."'"));
if($for['n']!=''){
$ex=explode(',',$for['n']);
$cc=0;
foreach($ex as $value){
  $cc=$cc+$my->rowk("Anlin_chat where chaid='$value' and kname='".$s['name']."'");
 }
if($cc=='0'){exit('该用户未在你管理的板块发言过,你不能操作它');}
}
}
//
if($s['qx']=='0'){
$my->gai("Anlin_user","qx='3' WHERE name='".htmlx($_GET['name'])."'");
exit('已解除限制');
}
if($s['qx']=='3'||$s['qx']=='4'){
$my->gai("Anlin_user","qx='0' WHERE name='".htmlx($_GET['name'])."'");
exit('已封禁该用户,再次点击可解锁');
}
exit('您不能操作该用户');
}

//删除数据库所有表和数据
if($mods=="sqldelete"){
login();
if($u['qx']!='1'){message('没有权限');}
/**
$result = $my->query("show table status from ".$my->sqlname);
while($data=$my->fetch($result)) {
if($data[Name]!='Anlin_user'&&$data[Name]!='Anlin_chat'){
if($my->query("drop table $data[Name]")){echo $data[Name].':yes<br>';}else{echo $data[Name].':no_error<br>';}
}
}**/
exit;
}
if($mods=='z'){
$my->query("CREATE TABLE `Anlin_userset` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `kname` varchar(255) NOT NULL DEFAULT '',
  `kuser` varchar(255) NOT NULL DEFAULT '',
  `kpass` varchar(255) NOT NULL DEFAULT '',
  `blacklist` text NOT NULL DEFAULT '',
  `qx` int(10) NOT NULL DEFAULT '0',   
  `md5` varchar(255) NOT NULL DEFAULT '', 
  `mail` varchar(255) NOT NULL DEFAULT '', 
  `time` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=0 DEFAULT CHARSET=utf8");
exit('666');
/**
if($my->query("ALTER TABLE `Anlin_chatlist` ADD `img` varchar(255) NOT NULL DEFAULT ''")){
exit('1');}else{exit('No');}
**/
}
//发布帖子
if($mods=="bbsgo"){
if($u['qx']!='1'&&$u['qx']!='2'){message('没有权限');}
$title=htmlx($_POST['title']);
$content=htmlx($_POST['content']);
$chaid=htmlx($_GET['chaid']);
if($my->rowk("Anlin_chatlist WHERE id='$chaid'")<1){exit('板块不存在');}
adminlok($chaid);
$qx=1;
$d=htmlx($_POST['d']);
if(!is_numeric($d)||$d==''){exit('初始热度必须为数字');}

if($title==''){exit('标题不能为空');}


//file 
$file=$_FILES[file];
if($file["name"]!=""){
if($a['file']!='1'){exit('管理员已禁止图片发送');}
$filebk=mb_substr($file["name"],mb_strlen($file["name"],'utf8')-3,mb_strlen($file["name"],'utf8'),'utf-8');
$filebk=strtolower($filebk);
if(in_array($filebk,array('png','gif','jpg','peg'))){}else{exit('文件格式错误');}
$os[filesize]=$a['fibk'];
if(($file["size"]/1024)>$os[filesize]){
if($os[filesize]>1024){
$fsi=ceil($os[filesize]/1024)."MB";
}else{$fsi=ceil($os[filesize]).'KB';}
exit('图片不能大于'.$fsi);
}

$filename=$time.str_replace("%",'_',urlencode($u['name'].'-'.$file["name"]));
//if(file_exists("./imgcache/".$filename)){exit('请勿重复发送文件,请修改文件名');}
if(move_uploaded_file($file["tmp_name"],"./imgcache/".$filename)){
list($width,$height)=getimagesize("./imgcache/".$filename);
$content.='[img='.$height.']./imgcache/'.$filename.'[/img]';
}
}
//file 

if($my->zeng("Anlin_chatbbs","NULL,'$chaid','$title','$qx','$content','$d','0','$time'")){exit("发布成功");}
exit('发布失败');
}
//发布帖子结束
//删除帖子
if($mods=='bbsde'){
if($u['qx']!='1'&&$u['qx']!='2'){exit('没有权限');}
$id=htmlx($_GET['id']);
$chas=$my->fetch($my->query("SELECT id,chaid FROM Anlin_chatbbs where id='$id'"));
adminlok($chas['chaid']);
$my->shan("Anlin_chatbbs","id='$id'");
$my->shan("Anlin_chatbbshui","bbsid='$id'");
exit('删除成功');
}

//删除帖子结束
//创建聊天室
if($mods=='chatlist'){
login();
if($u['qx']!='1'){message('没有权限');}
$po=htmlx($_POST['title']);
if($po==''){message('聊天室名不能为空');}
$k=$my->rowk("Anlin_chatlist WHERE title='$po'");
if($k>0){message('已存在相同聊天室名称,请修改后重新创建');}
if($my->zeng('Anlin_chatlist',"NULL,'$po','0','','$time',''")){message('创建成功');}
message('创建失败');
}


/**管理员操作项结束**/

//会员头像修改
if($mods=='xgtx'){
//file 
login();
$file=$_FILES[file];
if($file["name"]!=""){
if($a['tx']!='1'){exit('管理员已禁止修改头像');}
$filebk=mb_substr($file["name"],mb_strlen($file["name"],'utf8')-3,mb_strlen($file["name"],'utf8'),'utf-8');
$filebk=strtolower($filebk);
if(in_array($filebk,array('png','gif','jpg','peg'))){}else{exit('文件格式错误');}
$os[filesize]='500';
if(($file["size"]/1024)>$os[filesize]){
if($os[filesize]>1024){
$fsi=ceil($os[filesize]/1024)."MB";
}else{$fsi=ceil($os[filesize]).'KB';}
exit('图片不能大于500KB');
}
include './imgs.php';
$filename=str_replace("%",'_',urlencode($u['name'].'.png'));
$tlu="./tx/".$filename;
@unlink($tlu);
if(move_uploaded_file($file["tmp_name"],$tlu)){
imgc($tlu,250,250,$tlu);

if($my->gai("Anlin_user","tx='$tlu' WHERE name='".$u['name']."'")){exit('修改成功,请清除浏览器缓存');}
}
}
//file 


}

//会员头像修改结束

//论坛回帖
if($mods=='bbshui'){
login();
$po=htmlx($_POST['content']);
ubbyz($po);
$y=htmlx($_POST['y']);
$sname=htmlx($_POST['sname']);
if($u['qx']>2){
if(mb($po)>$a['z']){exit('字数超过上限,请修改后提交');}
}
if($po==''){exit('请输入内容');}
$bbsid=htmlx($_GET['bbsid']);
if($my->rowk("Anlin_chatbbs WHERE id=".$bbsid)<1){exit('帖子不存在');}

if($y!=''){
if($my->rowk("Anlin_chatbbshui WHERE id='$y'")<1){exit('回复的楼层不存在');}
$orna=$my->fetch($my->query("SELECT name,user FROM Anlin_user where name='$sname'"));
if($orna['user']==''){exit('回复的用户不存在');}
$sname=$orna['user'];//此处sname不是用户名
}
if($my->rowk("Anlin_chatbbs WHERE id='$bbsid' and qx='1'")<1){exit('该帖子已关闭回复');}

//file 
$file=$_FILES[file];
if($file["name"]!=""){
if($a['file']!='1'){exit('管理员已禁止图片发送');}
$filebk=mb_substr($file["name"],mb_strlen($file["name"],'utf8')-3,mb_strlen($file["name"],'utf8'),'utf-8');
$filebk=strtolower($filebk);
if(in_array($filebk,array('png','gif','jpg','peg'))){}else{exit('文件格式错误');}
$os[filesize]=$a['fibk'];
if(($file["size"]/1024)>$os[filesize]){
if($os[filesize]>1024){
$fsi=ceil($os[filesize]/1024)."MB";
}else{$fsi=ceil($os[filesize]).'KB';}
exit('图片不能大于'.$fsi);
}

$filename=$time.str_replace("%",'_',urlencode($u['name'].'-'.$file["name"]));
//if(file_exists("./imgcache/".$filename)){exit('请勿重复发送文件,请修改文件名');}
if(move_uploaded_file($file["tmp_name"],"./imgcache/".$filename)){
list($width,$height)=getimagesize("./imgcache/".$filename);
$po.='[img='.$height.']./imgcache/'.$filename.'[/img]';
}
}
//file 
if(md5($po)==$_COOKIE['cl']){exit('请勿重复发送消息');}
kie('cl',md5($po));
if($my->zeng('Anlin_chatbbshui',"NULL,'$bbsid','".$u['name']."','$sname','$po','".$u['user']."','".$u['qx']."','$y','$time'")){
$my->gai("Anlin_chatbbs","h='$time' where id='$bbsid'");
exit('回复成功:'.$y);
}



}
//论坛回帖结束



//聊天消息发送
if($mods=='chat'){
login();
$po=htmlx($_POST['content']);
ubbyz($po);
$dwid=htmlx($_POST['dwid']);
if($dwid!=''){
if(strlen($dwid)!=10){exit('Error:www.20wl.cn');}else{

$sname=htmlx($_POST['sname']);
}
}//dwid


if($u['qx']>2){
if(mb($po)>$a['z']){exit('字数超过上限,请修改后提交');}
}
if($po==''){exit('请输入内容');}
$chaid=htmlx($_GET['chaid']);
if($_GET['ac']=='mess'){

$sname=htmlx($_GET['sname']);
$ume=$u['name'];
if($chaid==''){//chaid
if($my->rowk("Anlin_user WHERE name='$sname'")<1){exit('用户不存在');}
$mid=$my->fetch($my->query("SELECT   id,kname,sname FROM Anlin_chatmesslist WHERE kname='$sname' and sname='$ume' or sname='$sname' and kname='$ume'"));
if($mid['id']==''){//mid
$my->zeng('Anlin_chatmesslist',"NULL,'".$u['name']."','$sname','...','$time'") or die('504');
$mid=$my->fetch($my->query("SELECT   id,kname,sname FROM Anlin_chatmesslist WHERE kname='$sname' and sname='$ume' or sname='$sname' and kname='$ume'"));

//time desc
//mid
}
$chaid=$mid['id'];
//chaid
}else{//此处是chatmess
if($my->rowk("Anlin_chatmesslist WHERE id=".$chaid)<1){exit('id_error');}
}
$biao='mess';
if($u['qx']=='3'||$u['qx']=='4'){
if($a['mess']!=1){
if($my->rowk("Anlin_user WHERE name='$sname' and qx='3' or qx='4'")>0){
exit('管理员已禁止私聊');
}
}
}
//mess
}else{//此处为chat不是chatmess
if($my->rowk("Anlin_chatlist WHERE id=".$chaid)<1){exit('聊天室不存在:id_error');}
if($u['qx']!='1'&&$u['qx']!='2'){
if($a['go']!='1'){exit('已关闭聊天室发言');}
if($my->rowk("Anlin_chatlist WHERE id='$chaid' and qx='0'")<1){exit('该聊天室已关闭发言');}
}
}

if($_GET['ac']!='mess'){//mess
if($sname!=''){
$mama=$my->fetch($my->query("SELECT   name,user FROM Anlin_user WHERE name='$sname'"));
if($mama['user']==''){exit('回复的用户不存在');}else{$po='<b>回复:'.$mama['user'].' </b>'.$po;}
}
if($sname==$u['name']){exit('你不能@自己');}
}//mess
//file 
$file=$_FILES[file];
if($file["name"]!=""){
if($a['file']!='1'){exit('管理员已禁止图片发送');}
$filebk=mb_substr($file["name"],mb_strlen($file["name"],'utf8')-3,mb_strlen($file["name"],'utf8'),'utf-8');
$filebk=strtolower($filebk);
if(in_array($filebk,array('png','gif','jpg','peg'))){}else{exit('文件格式错误');}
$os[filesize]=$a['fibk'];
if(($file["size"]/1024)>$os[filesize]){
if($os[filesize]>1024){
$fsi=ceil($os[filesize]/1024)."MB";
}else{$fsi=ceil($os[filesize]).'KB';}
exit('图片不能大于'.$fsi);
}

$filename=$time.str_replace("%",'_',urlencode($u['name'].'-'.$file["name"]));
//if(file_exists("./imgcache/".$filename)){exit('请勿重复发送文件,请修改文件名');}
if(move_uploaded_file($file["tmp_name"],"./imgcache/".$filename)){
list($width,$height)=getimagesize("./imgcache/".$filename);
$po.='[img='.$height.']./imgcache/'.$filename.'[/img]';
}
}
//file 

if(md5($po)==$_COOKIE['cl']){exit('请勿重复发送消息');}
kie('cl',md5($po));
//防STYLE注入
//if(strstr($po))
//防止自定义style样式

if($my->zeng('Anlin_chat'.$biao,"NULL,'$chaid','".$u['name']."','$sname','$po','".$u['user']."','".$u['qx']."','$dwid','$time'")){
if($biao!=''){
$my->gai("Anlin_chatmesslist","y='$po',time='$time' WHERE id='$chaid'");
}

exit('发送成功');}else{exit('出错');}

//$u-qx为用户表权限,大于3时该消息普通用户无法看到
}




exit;
//$_SESSION['y']=1;
echo UTF8;


?>


<form action="?h=zeng&mods=chatlist" method="post">
名称<input type="text" name="title" ><br>



<input type="submit" value="创建聊天室">
</form>

<form action="?h=zeng&mods=login" method="post">
账号<input type="text" name="name" ><br>

密码<input type="password" name="pass" ><br>

<input type="submit" value="提交">
</form>

<form action="?h=zeng&mods=reg" method="post">
账号<input type="text" name="name" ><br>
昵称<input type="text" name="user" ><br>
密码<input type="password" name="pass" ><br>
确认密码<input type="text" name="rpass" ><br>
<?if($a['zc']==1){echo'邀请码<input type="text" name="code" placeholder="必填">';}?>
<input type="submit" value="提交">
</form>

<form method="post" action="?h=zeng&mods=chat&chaid=1" enctype="multipart/form-data" id="J-add-form">
<textarea id="content" placeholder="输入内容" type="text" name="content" onclick=""></textarea>
 <input type="file" name="file" id="cfile" onchange="show(this)" style="display:n;">
<input type="submit" id="Xx" value="发送" onclick="chatpost(this.id,this.value);">
</form>

  <div id="textcon" style="width:845px;height:400px;line-height:20px;padding:4px;font-size:17px;color:#000;overflow-y:auto;-webkit-user-modify: read-write-plaintext-only;"></div>