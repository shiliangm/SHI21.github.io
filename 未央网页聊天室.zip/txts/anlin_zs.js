
function imtu(uc){
by('ttt').style.display='flex';
by('tt2').src=uc;
$("#tt2").css('background','#fff');
}
function loadScript(url, callback) {
$("#lojs").remove();
  var script = document.createElement("script");
  script.type = "text/javascript";
  if(typeof(callback) != "undefined"){
    if (script.readyState) {
      script.onreadystatechange = function () {
        if (script.readyState == "loaded" || script.readyState == "complete") {
          script.onreadystatechange = null;
          callback();
        }
      };
    } else {
      script.onload = function () {
        callback();
      };
    }
  }
  script.id="lojs";
  script.src = url;
  document.body.appendChild(script);
}
getFloat = function(num, n) {
	n = n ? parseInt(n) : 0;
	if(n <= 0) {
		return Math.round(num);
	}
	num = Math.round(num * Math.pow(10, n)) / Math.pow(10, n); //四舍五入
	num = Number(num).toFixed(n); //补足位数
	return num;
};

loadScript("http://hq.sinajs.cn/list=sh000001", function () { 
var hu=hq_str_sh000001.split(',');
var s='#000000';
var e='';
if(hu[3]<hu[2]){s='#2faa00';e='⬇︎';}
if(hu[3]>hu[2]){s='#ff0000';e='⬆︎';}
$("body").append('<div id="anlin_p" style="position:fixed;right:5px;top:50px;padding:5px;line-height:20px;background-color:rgba(255,217,217,.8);border-radius:4px;color:'+s+';" onclick="imtu(\'http://image.sinajs.cn/newchart/daily/n/sh000001.gif\')">'+hu[0]+'<br>'+hu[3]+' '+e+'<br>'+getFloat(hu[3]/1-hu[2],3)+' '+getFloat((hu[3]-hu[2])/hu[2]*100,2)+'%</div>');



var mydate = new Date();
var day=mydate.getDay();
var H=mydate.getHours();
var ran=mydate.getTime();
if(day!=0&&day!=6){
if(H==9||H==12||H>9&&H<12||H>13&&H<15||H==13||H==15){
setInterval(function(){
loadScript("http://hq.sinajs.cn/list=sh000001", function () { 
var hu=hq_str_sh000001.split(',');
var s='#000000';
var e='';
if(hu[3]<hu[2]){s='#2faa00';e='⬇︎';}
if(hu[3]>hu[2]){s='#ff0000';e='⬆︎';}
$("#anlin_p").css('color',s);
$("#anlin_p").attr('onclick','imtu(\'http://image.sinajs.cn/newchart/daily/n/sh000001.gif?'+ran+'\');');
$("#anlin_p").html(hu[0]+'<br>'+hu[3]+' '+e+'<br>'+getFloat(hu[3]/1-hu[2],3)+' '+getFloat((hu[3]-hu[2])/hu[2]*100,2)+'%');
});
},1000);
}
}//20wl.cn  1-23

});
